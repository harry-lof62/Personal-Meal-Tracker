#!/usr/bin/env bash
# Concatenates the migrations into one script for the Supabase SQL Editor.
# Run from the repository root:  bash scripts/build-setup-sql.sh
set -euo pipefail
out="supabase/setup/nourish_complete_setup.sql"
{
  echo "-- ============================================================================="
  echo "-- Nourish – complete database setup (generated – do not edit by hand)"
  echo "-- Built from supabase/migrations/*.sql by scripts/build-setup-sql.sh"
  echo "--"
  echo "-- Paste into Supabase → SQL Editor → New query → Run."
  echo "-- Runs in one transaction: if anything fails, nothing is changed."
  echo "-- Safe to run again on an existing Nourish database."
  echo "-- ============================================================================="
  echo
  echo "begin;"
  for f in supabase/migrations/*.sql; do
    echo
    echo "-- >>>>>>>>>>>>>>>>>>>> $(basename "$f") >>>>>>>>>>>>>>>>>>>>"
    cat "$f"
  done
  echo
  echo "commit;"
} > "$out"
echo "Wrote $out ($(wc -l < "$out") lines)"
