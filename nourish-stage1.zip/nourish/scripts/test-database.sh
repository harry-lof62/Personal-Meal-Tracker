#!/usr/bin/env bash
# Runs the migrations and the test suite against a LOCAL PostgreSQL 15+ server
# (never your Supabase project). Requires psql, createdb and dropdb on PATH and
# a role allowed to create databases. Run from the repository root:
#   bash scripts/test-database.sh
set -euo pipefail
DB="${NOURISH_TEST_DB:-nourish_test}"
run() { psql -X -q -v ON_ERROR_STOP=1 -d "$DB" "$@"; }
# Migrations print harmless "already exists, skipping" notices on re-runs; hide them.
quiet() { PGOPTIONS="-c client_min_messages=warning" run "$@"; }

fresh_db() {
  dropdb --if-exists "$DB" 2>/dev/null
  createdb "$DB"
  quiet -f supabase/tests/local_supabase_shim.sql
}

echo "== 1. Individual migrations, applied twice (re-run safety)"
fresh_db
for pass in 1 2; do
  for f in supabase/migrations/*.sql; do quiet -f "$f"; done
  echo "   pass $pass ok"
done
run -o /dev/null -f supabase/tests/database_tests.sql 2>&1 | sed 's/^psql:[^ ]* NOTICE:  /   /'

echo
echo "== 2. Consolidated setup script, applied twice, on a fresh database"
fresh_db
quiet -f supabase/setup/nourish_complete_setup.sql
quiet -f supabase/setup/nourish_complete_setup.sql
run -o /dev/null -f supabase/tests/database_tests.sql 2>&1 | grep -E "FAIL|ALL DATABASE TESTS PASSED"

dropdb --if-exists "$DB"
