// Copy this file to js/config.js for local testing (js/config.js is git-ignored).
// On Netlify, js/config.js is generated at build time from the SUPABASE_URL and
// SUPABASE_ANON_KEY environment variables – see docs/SUPABASE_SETUP.md.
//
// Only the PUBLIC key belongs here: the "anon" key or the "publishable" key
// (starts sb_publishable_). Never the service_role or secret key.
export default Object.freeze({
  supabaseUrl: 'https://YOUR_PROJECT_REF.supabase.co',
  supabaseAnonKey: 'YOUR_ANON_OR_PUBLISHABLE_KEY',
});
