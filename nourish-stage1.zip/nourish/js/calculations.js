// =============================================================================
// Nourish – calculations.js
// Every nutrition number shown in the app is calculated here, deterministically.
// Claude never calculates totals. The formula matches the database exactly:
//
//     amount = value_per_basis × quantity ÷ basis
//     basis  = 100 for g / ml, 1 for portions
//
// NULL (unknown) values stay null. They are never treated as zero; totals
// report how many items were missing a value instead.
// =============================================================================

export const NUTRIENTS = Object.freeze([
  { key: 'energy_kcal', label: 'Calories',           unit: 'kcal', decimals: 0 },
  { key: 'protein_g',   label: 'Protein',            unit: 'g',    decimals: 1 },
  { key: 'carbs_g',     label: 'Carbohydrates',      unit: 'g',    decimals: 1 },
  { key: 'sugars_g',    label: 'of which sugars',    unit: 'g',    decimals: 1 },
  { key: 'fat_g',       label: 'Fat',                unit: 'g',    decimals: 1 },
  { key: 'sat_fat_g',   label: 'of which saturates', unit: 'g',    decimals: 1 },
  { key: 'fibre_g',     label: 'Fibre',              unit: 'g',    decimals: 1 },
  { key: 'salt_g',      label: 'Salt',               unit: 'g',    decimals: 2 },
]);

export const NUTRIENT_KEYS = Object.freeze(NUTRIENTS.map((n) => n.key));

/** The six nutrients with daily targets, and how each target behaves. */
export const TARGET_KINDS = Object.freeze({
  energy_kcal: 'budget', // aim for it; going over is over
  protein_g:   'goal',   // reach at least this
  carbs_g:     'budget',
  fat_g:       'budget',
  fibre_g:     'goal',
  salt_g:      'limit',  // a maximum
});

// Float noise (0.1 + 0.2) is trimmed to 6 decimal places after each step.
const tidy = (x) => Math.round(x * 1e6) / 1e6;

function toNumberOrNull(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}

export function basisFor(unit) {
  if (unit === 'portion') return 1;
  if (unit === 'g' || unit === 'ml') return 100;
  throw new RangeError(`Unknown unit "${unit}" (expected g, ml or portion)`);
}

/** Library food row (energy_kcal_100, …) → { energy_kcal, … } per 100 g/ml. */
export function per100FromFood(food) {
  const out = {};
  for (const key of NUTRIENT_KEYS) out[key] = toNumberOrNull(food?.[`${key}_100`]);
  return out;
}

/** Diary row (snap_energy_kcal, …) → { energy_kcal, … } per basis. */
export function snapshotFromEntry(entry) {
  const out = {};
  for (const key of NUTRIENT_KEYS) out[key] = toNumberOrNull(entry?.[`snap_${key}`]);
  return out;
}

/**
 * Nutrition for an amount of food.
 * nutrientsForQuantity({ energy_kcal: 120 }, 150, 'g') → { energy_kcal: 180, … }
 */
export function nutrientsForQuantity(perBasis, quantity, unit = 'g') {
  const q = toNumberOrNull(quantity);
  if (q === null || q <= 0) throw new RangeError('Quantity must be a number greater than 0');
  const basis = basisFor(unit);
  const out = {};
  for (const key of NUTRIENT_KEYS) {
    const v = toNumberOrNull(perBasis?.[key]);
    out[key] = v === null ? null : tidy((v * q) / basis);
  }
  return out;
}

/** Line totals for a diary entry row from Supabase (uses its snapshot). */
export function entryNutrients(entry) {
  return nutrientsForQuantity(snapshotFromEntry(entry), entry.quantity, entry.quantity_unit);
}

/**
 * Sum a list of nutrient objects.
 * Returns { totals, missing, count }. missing[key] > 0 means totals[key] is a
 * lower bound because some items had no value for it.
 */
export function sumNutrients(items) {
  const totals = {};
  const missing = {};
  for (const key of NUTRIENT_KEYS) { totals[key] = 0; missing[key] = 0; }
  let count = 0;
  for (const item of items ?? []) {
    count += 1;
    for (const key of NUTRIENT_KEYS) {
      const v = toNumberOrNull(item?.[key]);
      if (v === null) missing[key] += 1;
      else totals[key] = tidy(totals[key] + v);
    }
  }
  return { totals, missing, count };
}

/** Totals for each meal and the whole day from diary rows. */
export function dayTotals(entries) {
  const meals = { breakfast: [], lunch: [], dinner: [], snacks: [] };
  for (const e of entries ?? []) {
    if (!meals[e.meal]) throw new RangeError(`Unknown meal "${e.meal}"`);
    meals[e.meal].push(entryNutrients(e));
  }
  const byMeal = {};
  for (const [meal, list] of Object.entries(meals)) byMeal[meal] = sumNutrients(list);
  return { byMeal, day: sumNutrients(Object.values(meals).flat()) };
}

/**
 * Progress against one target.
 * Returns { target, consumed, remaining, percent, over } where remaining can
 * be negative (over target). percent is unrounded.
 */
export function progress(consumed, target) {
  const c = toNumberOrNull(consumed) ?? 0;
  const t = toNumberOrNull(target);
  if (t === null || t <= 0) {
    return { target: null, consumed: c, remaining: null, percent: null, over: false };
  }
  return {
    target: t,
    consumed: c,
    remaining: tidy(t - c),
    percent: tidy((c / t) * 100),
    over: c > t,
  };
}

/**
 * Recipe nutrition from ingredient quantities and current library values.
 * ingredients: [{ quantity, unit, food: <foods row> }]
 */
export function recipeNutrition(ingredients, portions) {
  const p = toNumberOrNull(portions);
  if (p === null || p <= 0) throw new RangeError('Portions must be greater than 0');
  const lines = (ingredients ?? []).map((ing) =>
    nutrientsForQuantity(per100FromFood(ing.food), ing.quantity, ing.unit ?? ing.food?.base_unit ?? 'g'));
  const { totals, missing, count } = sumNutrients(lines);
  const perPortion = {};
  for (const key of NUTRIENT_KEYS) perPortion[key] = count === 0 ? null : tidy(totals[key] / p);
  return { totals: count === 0 ? null : totals, perPortion, missing, ingredientCount: count };
}

// ---------------------------------------------------------------------------
// Label conversions (used by the scanner review screen)
// ---------------------------------------------------------------------------

/** kJ → kcal (1 kcal = 4.184 kJ). */
export function kjToKcal(kj) {
  const v = toNumberOrNull(kj);
  return v === null ? null : tidy(v / 4.184);
}

/** Sodium → salt, as defined in UK/EU labelling law (salt = sodium × 2.5). */
export function sodiumToSalt(sodiumGrams) {
  const v = toNumberOrNull(sodiumGrams);
  return v === null ? null : tidy(v * 2.5);
}

/** A per-serving label value → per 100 g/ml, given the serving size. */
export function perServingToPer100(valuePerServing, servingSize) {
  const v = toNumberOrNull(valuePerServing);
  const s = toNumberOrNull(servingSize);
  if (v === null) return null;
  if (s === null || s <= 0) throw new RangeError('Serving size must be greater than 0');
  return tidy((v * 100) / s);
}
