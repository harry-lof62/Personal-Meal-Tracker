// =============================================================================
// Nourish – setup-check.js
// Drives setup-check.html: verifies config, database, storage and sign-in
// against the real Supabase project. Uses no sample data.
// =============================================================================
import { getSupabase, getActiveConfig } from './supabase.js';
import { formatEnergy, formatGrams, localISODate } from './format.js';

const EXPECTED_TABLES = ['profiles', 'nutrition_targets', 'foods', 'food_diary', 'weight_entries',
  'recipes', 'recipe_ingredients', 'ai_interactions', 'ai_drafts', 'food_images'];
const EXPECTED_BUCKETS = ['label-scans', 'food-photos'];
const SETUP_SQL = 'supabase/setup/nourish_complete_setup.sql';

const el = (id) => document.getElementById(id);

/** detail: a string, or { text, items: [] } for a short list. */
function setCheck(name, state, detail) {
  const item = document.querySelector(`[data-check="${name}"]`);
  item.dataset.state = state;
  const box = item.querySelector('.check-detail');
  box.replaceChildren();
  const text = typeof detail === 'string' ? detail : detail.text;
  const p = document.createElement('p');
  p.textContent = text;
  box.append(p);
  if (detail.items?.length) {
    const ul = document.createElement('ul');
    for (const entry of detail.items) {
      const li = document.createElement('li');
      li.textContent = entry;
      ul.append(li);
    }
    box.append(ul);
  }
}

function explainHealthError(error, host) {
  const msg = `${error?.message ?? ''} ${error?.code ?? ''}`;
  if (/PGRST202|Could not find the function/i.test(msg)) {
    return `Nourish isn’t installed in this database yet. Run ${SETUP_SQL} in Supabase → SQL Editor, then reload this page.`;
  }
  if (/Invalid API key|No API key|JWT/i.test(msg)) {
    return 'Supabase rejected the key. Copy the anon (or publishable) key for this project again.';
  }
  if (/Failed to fetch|NetworkError|Load failed|fetch failed/i.test(msg)) {
    return `Couldn’t reach ${host}. Check the Project URL and your connection, and that the project isn’t paused (free projects pause after a week of inactivity).`;
  }
  return `Supabase returned an error: ${error?.message ?? 'unknown error'}`;
}

function explainSignInError(error) {
  if (/Invalid login credentials/i.test(error.message)) return 'Email or password is incorrect.';
  if (/Email not confirmed/i.test(error.message)) {
    return 'This email address hasn’t been confirmed. Use the link Supabase emailed, or tick “Auto Confirm User” when creating the user.';
  }
  return error.message;
}

function renderTargets(t) {
  const rows = [
    ['Calories', formatEnergy(t.energy_kcal)],
    ['Protein', formatGrams(t.protein_g, 0)],
    ['Carbohydrates', formatGrams(t.carbs_g, 0)],
    ['Fat', formatGrams(t.fat_g, 0)],
    ['Fibre', formatGrams(t.fibre_g, 0)],
    ['Salt (maximum)', formatGrams(t.salt_g, 1)],
  ];
  const dl = el('targets');
  dl.replaceChildren();
  for (const [label, value] of rows) {
    const wrap = document.createElement('div');
    const dt = document.createElement('dt');
    const dd = document.createElement('dd');
    dt.textContent = label;
    dd.textContent = value;
    wrap.append(dt, dd);
    dl.append(wrap);
  }
}

async function checkAccount(supabase, user) {
  setCheck('account', 'running', 'Reading your profile and nutrition targets');
  el('signin-panel').hidden = true;

  // Deliberately no user_id filter: Row Level Security alone must limit the
  // result to this user's single profile.
  const [profiles, targets] = await Promise.all([
    supabase.from('profiles').select('user_id, display_name'),
    supabase.rpc('get_nutrition_targets', { p_date: localISODate() }),
  ]);

  const error = profiles.error ?? targets.error;
  if (error) {
    setCheck('account', 'fail', `Signed in, but reading your data failed: ${error.message}`);
    return;
  }
  if (profiles.data.length !== 1 || profiles.data[0].user_id !== user.id) {
    setCheck('account', 'fail',
      `Expected to see exactly your own profile but found ${profiles.data.length}. Run ${SETUP_SQL} again – it creates missing profiles.`);
    return;
  }
  if (!targets.data || targets.data.energy_kcal == null) {
    setCheck('account', 'fail', `No nutrition targets found for your account. Run ${SETUP_SQL} again to add the defaults.`);
    return;
  }

  renderTargets(targets.data);
  el('account-email').textContent = user.email;
  el('account-panel').hidden = false;
  setCheck('account', 'ok', 'Signed in. Your profile and targets loaded, and only your own profile is visible.');
}

function showSignIn(supabase) {
  el('account-panel').hidden = true;
  el('signin-panel').hidden = false;
  setCheck('account', 'pending', 'Sign in below to load your profile');

  const form = el('signin-form');
  form.onsubmit = async (event) => {
    event.preventDefault();
    const email = form.email.value.trim();
    const password = form.password.value;
    const errorBox = el('signin-error');
    errorBox.textContent = '';
    if (!email || !password) { errorBox.textContent = 'Enter your email and password.'; return; }

    const button = form.querySelector('button');
    button.disabled = true;
    button.textContent = 'Signing in…';
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    button.disabled = false;
    button.textContent = 'Sign in and test';
    if (error) { errorBox.textContent = explainSignInError(error); return; }
    form.password.value = '';
    await checkAccount(supabase, data.user);
  };
}

async function run() {
  setCheck('config', 'running', 'Loading js/config.js');
  let supabase;
  try {
    supabase = await getSupabase();
  } catch (err) {
    setCheck('config', 'fail', err.message);
    setCheck('database', 'skipped', 'Waiting for settings');
    setCheck('storage', 'skipped', 'Waiting for settings');
    setCheck('account', 'skipped', 'Waiting for settings');
    return;
  }
  const host = new URL(getActiveConfig().supabaseUrl).host;
  setCheck('config', 'ok', `Using ${host} with a public key. No secret keys in the website.`);

  setCheck('database', 'running', `Checking the Nourish schema on ${host}`);
  const { data, error } = await supabase.rpc('nourish_health_check');
  if (error) {
    setCheck('database', 'fail', explainHealthError(error, host));
    setCheck('storage', 'skipped', 'Waiting for the database');
    setCheck('account', 'skipped', 'Waiting for the database');
    return;
  }

  const missing = EXPECTED_TABLES.filter((t) => !data.tables?.[t]?.exists);
  const unprotected = EXPECTED_TABLES.filter((t) => data.tables?.[t]?.exists && !data.tables[t].rls);
  if (missing.length || unprotected.length) {
    setCheck('database', 'fail', {
      text: `The schema is incomplete. Run ${SETUP_SQL} again.`,
      items: [...missing.map((t) => `${t}: missing`), ...unprotected.map((t) => `${t}: Row Level Security is off`)],
    });
  } else {
    setCheck('database', 'ok', `All ${EXPECTED_TABLES.length} tables are installed, each with Row Level Security on.`);
  }

  const buckets = data.buckets ?? [];
  const missingBuckets = EXPECTED_BUCKETS.filter((id) => !buckets.some((b) => b.id === id));
  const publicBuckets = buckets.filter((b) => b.public).map((b) => b.id);
  if (missingBuckets.length) {
    setCheck('storage', 'fail', { text: `Missing storage buckets. Run ${SETUP_SQL} again.`, items: missingBuckets });
  } else if (publicBuckets.length) {
    setCheck('storage', 'fail', {
      text: 'These buckets are public. Run the setup script again to make them private.',
      items: publicBuckets,
    });
  } else {
    setCheck('storage', 'ok', 'Both photo buckets exist and are private.');
  }

  const { data: { session } } = await supabase.auth.getSession();
  if (session) await checkAccount(supabase, session.user);
  else showSignIn(supabase);

  el('signout').onclick = async () => {
    await supabase.auth.signOut();
    showSignIn(supabase);
  };
}

run().catch((err) => {
  console.error(err);
  setCheck('config', 'fail', `Unexpected error: ${err.message}`);
});
