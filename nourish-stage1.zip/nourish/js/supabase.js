// =============================================================================
// Nourish – supabase.js
// Creates the single Supabase client used by the whole app.
//
// The browser only ever holds the PUBLIC key (legacy "anon" key or the newer
// "publishable" key). It is safe to ship because Row Level Security decides
// what each signed-in user can see. A secret / service_role key is refused.
// =============================================================================

// Pinned version, loaded as an ES module from jsDelivr.
export const SUPABASE_JS_URL = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm';

export class ConfigError extends Error {
  constructor(message) { super(message); this.name = 'ConfigError'; }
}

function decodeJwtPayload(token) {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  try {
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
    const json = typeof atob === 'function'
      ? atob(padded)
      : Buffer.from(padded, 'base64').toString('utf8');
    return JSON.parse(json);
  } catch {
    return null;
  }
}

/**
 * Throws ConfigError with a plain-English fix if the config is unusable or
 * unsafe. Shared by the browser and by scripts/build.mjs on Netlify.
 */
export function validateConfig(config) {
  const url = String(config?.supabaseUrl ?? '').trim();
  const key = String(config?.supabaseAnonKey ?? '').trim();

  if (!url || !key || /YOUR[_-]/i.test(url + key)) {
    throw new ConfigError(
      'Supabase settings are missing. Copy js/config.example.js to js/config.js and fill in your Project URL and anon (publishable) key.');
  }

  let parsed;
  try { parsed = new URL(url); } catch {
    throw new ConfigError(`"${url}" is not a valid URL. Use the Project URL from Supabase → Project Settings → API.`);
  }
  const isLocal = ['localhost', '127.0.0.1'].includes(parsed.hostname);
  if (parsed.protocol !== 'https:' && !isLocal) {
    throw new ConfigError('The Supabase URL must start with https://');
  }
  if (parsed.pathname.replace(/\/+$/, '') !== '') {
    throw new ConfigError('Use the bare Project URL (e.g. https://abcd1234.supabase.co) with nothing after .co');
  }

  if (key.startsWith('sb_secret_')) {
    throw new ConfigError('That is a SECRET key. Never put it in the website. Use the publishable (or anon) key instead, and rotate the secret key in Supabase if it has been shared.');
  }
  const payload = decodeJwtPayload(key);
  if (payload?.role === 'service_role') {
    throw new ConfigError('That is the service_role key, which bypasses all security. Never put it in the website. Use the anon key instead, and rotate the service_role key in Supabase if it has been shared.');
  }
  if (!key.startsWith('sb_publishable_') && payload?.role !== 'anon') {
    throw new ConfigError('The key is not recognised. Copy the anon / publishable key from Supabase → Project Settings → API Keys.');
  }

  return { supabaseUrl: parsed.origin, supabaseAnonKey: key };
}

let clientPromise = null;
let activeConfig = null;

/** The validated config in use (after getSupabase() has resolved). */
export function getActiveConfig() { return activeConfig; }

/** Returns the shared Supabase client (created on first use). */
export function getSupabase() {
  if (!clientPromise) {
    clientPromise = createAppClient().catch((err) => { clientPromise = null; throw err; });
  }
  return clientPromise;
}

async function createAppClient() {
  let config;
  try {
    ({ default: config } = await import('./config.js'));
  } catch {
    throw new ConfigError(
      'js/config.js was not found. For local testing copy js/config.example.js to js/config.js; on Netlify it is generated from environment variables.');
  }
  const { supabaseUrl, supabaseAnonKey } = validateConfig(config);
  activeConfig = Object.freeze({ supabaseUrl, supabaseAnonKey });

  let createClient;
  try {
    ({ createClient } = await import(SUPABASE_JS_URL));
  } catch {
    throw new Error('Could not load the Supabase library from cdn.jsdelivr.net. Check your internet connection.');
  }

  return createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: true,      // stay signed in across visits
      autoRefreshToken: true,
      detectSessionInUrl: true,  // needed for password-reset links
      storageKey: 'nourish-auth',
    },
  });
}
