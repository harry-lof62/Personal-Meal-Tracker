// =============================================================================
// Nourish – format.js
// Display formatting (UK conventions) and timezone-safe date helpers.
// Rounding happens ONLY here, at display time; stored and calculated values
// keep full precision.
// =============================================================================

const KG_PER_LB = 0.45359237;
const LB_PER_STONE = 14;

/** Round half away from zero without binary float surprises (1.005 → 1.01). */
export function round(value, decimals = 0) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) return null;
  const n = Number(value);
  const sign = n < 0 ? -1 : 1;
  return sign * Number(`${Math.round(Number(`${Math.abs(n)}e${decimals}`))}e-${decimals}`);
}

export function formatNumber(value, decimals = 0) {
  const r = round(value, decimals);
  if (r === null) return '–';
  return r.toLocaleString('en-GB', { minimumFractionDigits: 0, maximumFractionDigits: decimals });
}

/** 1800 → "1,800 kcal" */
export function formatEnergy(kcal) {
  return kcal === null || kcal === undefined ? '–' : `${formatNumber(kcal, 0)} kcal`;
}

/** 13.456 → "13.5 g"; salt uses 2 decimals. */
export function formatGrams(grams, decimals = 1) {
  return grams === null || grams === undefined ? '–' : `${formatNumber(grams, decimals)} g`;
}

export function formatQuantity(quantity, unit) {
  if (unit === 'portion') {
    const n = formatNumber(quantity, 2);
    return `${n} ${Number(quantity) === 1 ? 'portion' : 'portions'}`;
  }
  return `${formatNumber(quantity, 1)} ${unit}`;
}

// ---------------------------------------------------------------------------
// Dates. Diary dates are calendar days in the user's LOCAL time.
// Never use toISOString() for this – it gives the UTC date, which is
// yesterday's date for anything logged between midnight and 1 am in BST.
// ---------------------------------------------------------------------------

const pad = (n) => String(n).padStart(2, '0');

/** Date → "YYYY-MM-DD" in local time. */
export function localISODate(date = new Date()) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

/** "YYYY-MM-DD" → Date at local midnight. */
export function parseISODate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso ?? '');
  if (!m) throw new RangeError(`Not a YYYY-MM-DD date: "${iso}"`);
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  if (d.getMonth() !== Number(m[2]) - 1) throw new RangeError(`Not a real date: "${iso}"`);
  return d;
}

/** Add whole days to a "YYYY-MM-DD" date (DST-safe). */
export function addDays(iso, days) {
  const d = parseISODate(iso);
  d.setDate(d.getDate() + days);
  return localISODate(d);
}

/** "2026-11-03" → "03/11/2026" (or the user's chosen format). */
export function formatDate(iso, format = 'DD/MM/YYYY') {
  const [y, m, d] = iso.split('-');
  if (format === 'YYYY-MM-DD') return `${y}-${m}-${d}`;
  if (format === 'MM/DD/YYYY') return `${m}/${d}/${y}`;
  return `${d}/${m}/${y}`;
}

// ---------------------------------------------------------------------------
// Weight. Always stored in kg; converted only for display and input.
// ---------------------------------------------------------------------------

export function kgToLb(kg) { return kg / KG_PER_LB; }
export function lbToKg(lb) { return lb * KG_PER_LB; }

/** 88.5 → "88.5 kg" | "195.1 lb" | "13 st 13.1 lb" */
export function formatWeight(kg, unit = 'kg') {
  if (kg === null || kg === undefined) return '–';
  if (unit === 'lb') return `${formatNumber(kgToLb(kg), 1)} lb`;
  if (unit === 'st_lb') {
    const totalLb = round(kgToLb(kg), 1);
    let stones = Math.floor(totalLb / LB_PER_STONE);
    let pounds = round(totalLb - stones * LB_PER_STONE, 1);
    if (pounds >= LB_PER_STONE) { stones += 1; pounds = 0; }
    return `${stones} st ${formatNumber(pounds, 1)} lb`;
  }
  return `${formatNumber(kg, 1)} kg`;
}

/** Input in the user's unit → kg. st_lb takes { stones, pounds }. */
export function toKg(value, unit = 'kg') {
  if (unit === 'lb') return lbToKg(Number(value));
  if (unit === 'st_lb') return lbToKg(Number(value.stones) * LB_PER_STONE + Number(value.pounds || 0));
  return Number(value);
}
