import { test } from 'node:test';
import assert from 'node:assert/strict';
import { round, formatEnergy, formatGrams, formatQuantity, localISODate, parseISODate, addDays,
  formatDate, formatWeight, toKg } from '../js/format.js';

test('round half away from zero without float errors', () => {
  assert.equal(round(1.005, 2), 1.01);
  assert.equal(round(2.5, 0), 3);
  assert.equal(round(-2.5, 0), -3);
  assert.equal(round(null, 1), null);
});

test('UK number formats', () => {
  assert.equal(formatEnergy(1800), '1,800 kcal');
  assert.equal(formatEnergy(179.6), '180 kcal');
  assert.equal(formatGrams(13.456), '13.5 g');
  assert.equal(formatGrams(0.025, 2), '0.03 g');
  assert.equal(formatGrams(null), '–');
  assert.equal(formatQuantity(150, 'g'), '150 g');
  assert.equal(formatQuantity(1, 'portion'), '1 portion');
  assert.equal(formatQuantity(0.5, 'portion'), '0.5 portions');
});

test('local dates, not UTC dates', () => {
  assert.equal(localISODate(new Date(2026, 10, 3, 0, 30)), '2026-11-03');
  assert.equal(addDays('2026-03-28', 1), '2026-03-29'); // across the BST change
  assert.equal(addDays('2026-01-01', -1), '2025-12-31');
  assert.throws(() => parseISODate('2026-02-30'), RangeError);
  assert.throws(() => parseISODate('03/11/2026'), RangeError);
});

test('DD/MM/YYYY by default', () => {
  assert.equal(formatDate('2026-11-03'), '03/11/2026');
  assert.equal(formatDate('2026-11-03', 'YYYY-MM-DD'), '2026-11-03');
});

test('weights stored in kg, shown in the chosen unit', () => {
  assert.equal(formatWeight(88.5), '88.5 kg');
  assert.equal(formatWeight(88.5, 'lb'), '195.1 lb');
  assert.equal(formatWeight(88.5, 'st_lb'), '13 st 13.1 lb');
  assert.equal(formatWeight(63.5029, 'st_lb'), '10 st 0 lb');
  assert.ok(Math.abs(toKg({ stones: 13, pounds: 13.1 }, 'st_lb') - 88.495) < 0.01);
  assert.equal(toKg(88.5, 'kg'), 88.5);
});
