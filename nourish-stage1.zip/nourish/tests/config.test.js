import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateConfig, ConfigError } from '../js/supabase.js';

const jwt = (payload) => ['eyJhbGciOiJIUzI1NiJ9', Buffer.from(JSON.stringify(payload)).toString('base64url'), 'sig'].join('.');
const URL_OK = 'https://abcd1234.supabase.co';

test('accepts the anon key and the publishable key', () => {
  assert.equal(validateConfig({ supabaseUrl: URL_OK, supabaseAnonKey: jwt({ role: 'anon' }) }).supabaseUrl, URL_OK);
  assert.ok(validateConfig({ supabaseUrl: URL_OK + '/', supabaseAnonKey: 'sb_publishable_abc123' }));
});

test('refuses service_role and secret keys', () => {
  assert.throws(() => validateConfig({ supabaseUrl: URL_OK, supabaseAnonKey: jwt({ role: 'service_role' }) }), /service_role/);
  assert.throws(() => validateConfig({ supabaseUrl: URL_OK, supabaseAnonKey: 'sb_secret_abc' }), /SECRET/);
});

test('refuses placeholders, bad URLs and unknown keys', () => {
  assert.throws(() => validateConfig({ supabaseUrl: 'https://YOUR_PROJECT_REF.supabase.co', supabaseAnonKey: 'x' }), ConfigError);
  assert.throws(() => validateConfig({}), ConfigError);
  assert.throws(() => validateConfig({ supabaseUrl: 'http://abcd.supabase.co', supabaseAnonKey: 'sb_publishable_x' }), /https/);
  assert.throws(() => validateConfig({ supabaseUrl: URL_OK + '/rest/v1', supabaseAnonKey: 'sb_publishable_x' }), /bare Project URL/);
  assert.throws(() => validateConfig({ supabaseUrl: URL_OK, supabaseAnonKey: 'random-text' }), /not recognised/);
});

test('allows a local Supabase over http', () => {
  assert.ok(validateConfig({ supabaseUrl: 'http://127.0.0.1:54321', supabaseAnonKey: jwt({ role: 'anon' }) }));
});
