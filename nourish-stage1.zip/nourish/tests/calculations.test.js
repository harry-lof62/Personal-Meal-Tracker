import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  nutrientsForQuantity, per100FromFood, entryNutrients, sumNutrients, dayTotals,
  progress, recipeNutrition, kjToKcal, sodiumToSalt, perServingToPer100, basisFor,
} from '../js/calculations.js';

const oats = { name: 'Porridge Oats', base_unit: 'g', energy_kcal_100: 120, protein_g_100: 10, carbs_g_100: 60,
  sugars_g_100: 1, fat_g_100: 8, sat_fat_g_100: 1.5, fibre_g_100: 9, salt_g_100: 0.02 };

test('120 kcal per 100 g × 150 g = 180 kcal, same rule for every nutrient', () => {
  const r = nutrientsForQuantity(per100FromFood(oats), 150, 'g');
  assert.deepEqual(r, { energy_kcal: 180, protein_g: 15, carbs_g: 90, sugars_g: 1.5, fat_g: 12,
    sat_fat_g: 2.25, fibre_g: 13.5, salt_g: 0.03 });
});

test('portions use a basis of 1, g/ml a basis of 100', () => {
  assert.equal(basisFor('portion'), 1);
  assert.equal(basisFor('ml'), 100);
  assert.equal(nutrientsForQuantity({ energy_kcal: 650 }, 0.5, 'portion').energy_kcal, 325);
  assert.throws(() => basisFor('cups'), RangeError);
});

test('unknown values stay null – never zero', () => {
  const r = nutrientsForQuantity({ energy_kcal: 100, fat_g: null }, 50, 'g');
  assert.equal(r.energy_kcal, 50);
  assert.equal(r.fat_g, null);
  assert.equal(r.fibre_g, null);
});

test('rejects zero, negative and non-numeric quantities', () => {
  for (const q of [0, -5, 'abc', null, undefined, NaN]) {
    assert.throws(() => nutrientsForQuantity({ energy_kcal: 100 }, q, 'g'), RangeError);
  }
});

test('numeric strings from the API are accepted', () => {
  assert.equal(nutrientsForQuantity({ energy_kcal: '120.00' }, '150', 'g').energy_kcal, 180);
});

test('float noise is trimmed (0.1 + 0.2 style errors)', () => {
  const { totals } = sumNutrients([{ salt_g: 0.1 }, { salt_g: 0.2 }]);
  assert.equal(totals.salt_g, 0.3);
});

test('sumNutrients counts items missing a value', () => {
  const { totals, missing, count } = sumNutrients([{ energy_kcal: 100, fat_g: 5 }, { energy_kcal: 50, fat_g: null }]);
  assert.equal(count, 2);
  assert.equal(totals.energy_kcal, 150);
  assert.equal(totals.fat_g, 5);
  assert.equal(missing.fat_g, 1);
  assert.equal(missing.energy_kcal, 0);
});

test('dayTotals matches the database test case (240 + 325 = 565 kcal)', () => {
  const entries = [
    { meal: 'breakfast', quantity: 200, quantity_unit: 'g', snap_energy_kcal: 120, snap_protein_g: 10,
      snap_carbs_g: 60, snap_fat_g: 8, snap_fibre_g: 9, snap_salt_g: 0.02 },
    { meal: 'dinner', quantity: 0.5, quantity_unit: 'portion', snap_energy_kcal: 650, snap_protein_g: 40 },
  ];
  const { byMeal, day } = dayTotals(entries);
  assert.equal(byMeal.breakfast.totals.energy_kcal, 240);
  assert.equal(byMeal.dinner.totals.energy_kcal, 325);
  assert.equal(byMeal.lunch.count, 0);
  assert.equal(day.totals.energy_kcal, 565);
  assert.equal(day.totals.protein_g, 40);
  assert.equal(day.missing.fat_g, 1);
  assert.throws(() => dayTotals([{ meal: 'brunch', quantity: 1, quantity_unit: 'g' }]), RangeError);
});

test('entryNutrients uses the snapshot, not the current food', () => {
  const entry = { quantity: 150, quantity_unit: 'g', snap_energy_kcal: 120, food: { energy_kcal_100: 200 } };
  assert.equal(entryNutrients(entry).energy_kcal, 180);
});

test('progress: remaining, percent and over', () => {
  assert.deepEqual(progress(1350, 1800), { target: 1800, consumed: 1350, remaining: 450, percent: 75, over: false });
  const over = progress(7.5, 6);
  assert.equal(over.remaining, -1.5);
  assert.equal(over.over, true);
  assert.equal(progress(10, null).percent, null);
  assert.equal(progress(null, 160).consumed, 0);
});

test('recipe totals and per-portion values (matches database test: 300 kcal, 150 per portion)', () => {
  const milk = { base_unit: 'ml', energy_kcal_100: 50, protein_g_100: 3.6 };
  const r = recipeNutrition([
    { quantity: 100, unit: 'g', food: { ...oats, energy_kcal_100: 200 } },
    { quantity: 200, unit: 'ml', food: milk },
  ], 2);
  assert.equal(r.totals.energy_kcal, 300);
  assert.equal(r.perPortion.energy_kcal, 150);
  assert.equal(r.perPortion.protein_g, 8.6);
  assert.equal(r.missing.fibre_g, 1);
  assert.equal(r.ingredientCount, 2);
  assert.equal(recipeNutrition([], 4).perPortion.energy_kcal, null);
  assert.throws(() => recipeNutrition([], 0), RangeError);
});

test('label conversions', () => {
  assert.equal(kjToKcal(1569), 375);           // 1569 kJ ≈ 375 kcal
  assert.equal(sodiumToSalt(0.4), 1);          // 0.4 g sodium = 1 g salt
  assert.equal(perServingToPer100(9, 45), 20); // 9 g in a 45 g serving = 20 g/100 g
  assert.equal(perServingToPer100(null, 45), null);
  assert.throws(() => perServingToPer100(9, 0), RangeError);
});
