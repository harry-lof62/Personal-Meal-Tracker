# Nourish – architecture

This document records the technical decisions behind Nourish and why they were made. It is the reference for every later stage.

## The shape of the system

```
 Phone / desktop browser                Supabase project                    Anthropic
 ───────────────────────                ────────────────                    ─────────
 Static site on Netlify   ── HTTPS ──►  Auth (email + password)
 HTML + CSS + ES modules                PostgREST API ─► PostgreSQL + RLS
 supabase-js (public key)               Storage (private buckets)
                          ── HTTPS ──►  Edge Functions ───────── HTTPS ──►  Claude API
                          (user JWT)    (ANTHROPIC_API_KEY secret)          (vision + chat)
```

The browser never talks to Anthropic and never holds a secret. Everything it can reach is guarded by the signed-in user's token and Row Level Security.

## Key decisions

**1. Plain HTML, CSS and JavaScript modules, no framework.** Each screen is an ES module (`js/diary.js`, `js/dashboard.js` and so on). The only library is `supabase-js`, loaded from jsDelivr at a pinned version (2.45.4). There is no npm install for the website itself; `package.json` exists only so the built-in Node test runner and build script can run.

**2. One page app with real URLs.** Screens live at `/dashboard`, `/diary` etc. Netlify serves `index.html` for any path that isn't a real file, so refreshing a page or opening a bookmark works.

**3. Only the public key in the browser.** The site uses the Supabase *publishable* (or legacy *anon*) key. Both the browser and the Netlify build refuse a `service_role` or `sb_secret_` key outright. `js/config.js` is generated on Netlify from environment variables and is git-ignored locally.

**4. Row Level Security on every personal table.** Every row has a `user_id`. Policies allow a signed-in user to see and change only rows where `user_id = auth.uid()`. The signed-out `anon` role has no table access at all. Storage files live under `<user id>/…` with the same rule.

**5. Edge Functions run as the user, not as an administrator.** Each Edge Function forwards the caller's own access token to Supabase, so every query it makes is filtered by RLS exactly as in the browser. No service-role key is needed anywhere in the project. Claude is never given database access: the function selects a fixed set of facts (targets, totals, recent entries, library items) and sends those as context.

**6. Diary entries carry a nutrition snapshot.** When a food is logged, the database copies its name, brand and per-100 g values into the diary row (`snap_*` columns). Line totals are *generated columns* (`snapshot × quantity ÷ 100`), so they can never disagree with the quantity. Editing or deleting a food later never changes past days. A user can deliberately refresh a single entry if they corrected a mistake.

**7. Unknown is not zero.** Missing label values are stored as `NULL`. Totals report how many items lacked a value, so the app can say "at least 42 g protein" instead of silently under-counting.

**8. All arithmetic is deterministic code.** `js/calculations.js` and the database use the same formula, and their tests use the same numbers (150 g of a 120 kcal/100 g food = 180 kcal). Claude receives finished numbers and is instructed to use them, never to calculate totals.

**9. AI output is never saved without approval.** A scanned label is returned to the review screen and saved only when the user presses Save; the database itself rejects an `ai_scan` food without a `verified_at` time. Assistant suggestions are stored in `ai_drafts` as pending until the user approves them in the app.

**10. Photos are private and optional.** Label photos are converted to JPEG and reduced in size on the phone before upload (Claude accepts JPEG, PNG, GIF and WebP, not iPhone HEIC). They are stored only if the user has switched on "Keep label photos" (`profiles.save_scan_images`), and shown through short-lived signed URLs.

**11. Calendar days are local.** Diary dates are the user's local calendar day (UK by default), never derived from UTC, so a snack at 00:30 BST lands on the right day.

**12. Configurable Claude model.** The model ID is a Supabase secret (`ANTHROPIC_MODEL`) with a sensible default, chosen and verified against Anthropic's current model list in Stage 3.

## Database

| Table | Holds | Notes |
|---|---|---|
| `profiles` | Name, date of birth, height, weights, activity level, unit and date preferences | One per user, created automatically at sign-up. `current_weight_kg` follows the latest weight entry. |
| `nutrition_targets` | Calorie, protein, carbohydrate, fat, fibre and salt targets | Dated (`effective_from`), so past days are judged against the targets in force then. Defaults 1,800 / 160 / 150 / 60 / 30 / 6. |
| `foods` | The food library, per 100 g or 100 ml | Barcode unique per user among live products. Fuzzy search index. Source: manual, AI scan or Open Food Facts. |
| `food_diary` | Logged items with nutrition snapshots | Units g, ml or portion. Totals are generated columns. |
| `weight_entries` | One weight per day, in kg | Never altered automatically. |
| `recipes`, `recipe_ingredients` | Recipes and their quantities | Nutrition calculated live from ingredients by the `recipe_nutrition` view. |
| `ai_interactions` | Audit log of every Claude call | Append-only: no edits allowed. Used for rate limiting. |
| `ai_drafts` | Suggestions waiting for approval | Pending → approved / rejected. |
| `food_images` | Metadata for photos in Storage | Path must be inside the owner's folder. |

**Deletion rules.** Deleting a food keeps all diary history (the link becomes empty, the snapshot stays). A food used in a recipe cannot be deleted; the app archives it instead. Deleting a recipe removes its ingredient lines but not diary entries logged from it. Deleting the whole account removes everything belonging to it.

**Database functions** callable from the app: `get_nutrition_targets(date)`, `search_foods(text, limit)`, `find_similar_foods(name, brand, barcode)` (duplicate check before saving a scan), `copy_meal(from_date, from_meal, to_date, to_meal)`, `refresh_diary_entry_snapshot(entry_id)`, and `nourish_health_check()` for the setup page.

## External data

Open Food Facts barcode lookups are made directly from the browser (free, no key). Products saved from it are marked `source = 'open_food_facts'` with the product URL, and the app shows the attribution required by its Open Database Licence.

## Stage plan

| Stage | Scope | Status |
|---|---|---|
| 1 | Architecture, repository, SQL, Supabase setup, connectivity | Built and tested locally; waiting for your Supabase project |
| 2 | Design system, sign-in and password reset, dashboard, diary, food library | Next |
| 3 | Anthropic setup, Edge Functions, label scanner, assistant | |
| 4 | Weight tracking, progress charts, recipes, meal planning | |
| 5 | Full test pass, GitHub, Netlify deployment, final documentation | |
