# Setting up Supabase for Nourish

This takes about 20 minutes on a computer. You'll create a free Supabase project, install the Nourish database, create your login and check that everything connects.

You will never need to send anyone your keys or passwords, including in a chat with Claude. Keys go only into the places these instructions name.

Supabase occasionally renames items in its dashboard. If a menu name below doesn't match exactly, look for the nearest equivalent in the same area.

---

## Part A – Create the project

1. Go to **supabase.com** and sign up (with GitHub or email).
2. Click **New project** and fill in:
   - **Organisation:** your personal one, on the Free plan.
   - **Project name:** `nourish`.
   - **Database password:** click *Generate a password* and save it in your password manager. You won't need it day to day.
   - **Region:** *West EU (London)*.
3. Click **Create new project** and wait a minute or two until the dashboard is ready.

Free projects pause after about a week without any activity. If that happens, open the project in the dashboard and click **Restore**. Your data is kept.

---

## Part B – Install the database

1. On your computer, open `supabase/setup/nourish_complete_setup.sql` from the Nourish folder in a plain text editor (TextEdit or Notepad), select everything and copy it.
2. In Supabase, open **SQL Editor** in the left sidebar and start a **New query**.
3. Paste the script and click **Run**.
4. Supabase may warn that the query contains *destructive operations*. Choose **Run this query**. The only things the script drops are its own security rules and triggers, which it immediately recreates. It never deletes data.
5. You should see **Success. No rows returned**.

The whole script runs as one transaction. If any part fails, nothing is changed. You can fix the problem and run it again, and you can safely re-run it at any time.

**Check it worked**

- **Table Editor** lists these 10 tables:
  - `ai_drafts`
  - `ai_interactions`
  - `food_diary`
  - `food_images`
  - `foods`
  - `nutrition_targets`
  - `profiles`
  - `recipe_ingredients`
  - `recipes`
  - `weight_entries`
- **Storage** lists two buckets, `label-scans` and `food-photos`, and neither is marked Public.

The **Security Advisor** may mention `nourish_health_check` as a function that signed-out visitors can run. That is intentional. It powers the connection check and only reports whether the tables exist and have their security rules on. It returns no data.

If the script fails, copy the exact error message, and include it when you report back.

---

## Part C – Create your login

1. Go to **Authentication → Users**.
2. Click **Add user**, then **Create new user**.
3. Enter your email address and a strong password, and tick **Auto Confirm User**.
4. Click **Create user**.

**Check it worked:** in **Table Editor**, the `profiles` table has one row and `nutrition_targets` has one row with 1800 / 160 / 150 / 60 / 30 / 6. These are starting values only. You'll change them, along with your name and weights, on the Settings screen in Stage 2.

---

## Part D – Close public sign-ups

Nourish is personal, so nobody else should be able to create an account.

1. Go to **Authentication → Sign In / Providers**. In some dashboards this is **Authentication → Settings**.
2. Turn off **Allow new users to sign up**.
3. Click **Save**.

Leave the **Email** provider switched on, because you need it to sign in.

Even with sign-ups open, other people could never see your data, but they could use your storage and, from Stage 3, your Anthropic credit.

---

## Part E – Find the two public values

You need two values, and both are designed to be public.

- **Project URL:** go to **Project Settings → Data API** (older dashboards: **Settings → API**). It looks like `https://abcdefghijklmnop.supabase.co`.
- **Public key:** go to **Project Settings → API Keys** and copy one of these:
  - the **Publishable key**, which starts `sb_publishable_`;
  - or, on the *Legacy API keys* tab, the **anon public** key.

**Never use the secret key** (`sb_secret_…`) or the **service_role** key. Either one bypasses every security rule. Nourish refuses them, but don't paste them anywhere.

---

## Part F – Run the connection check

Browsers won't run Nourish's code from a file opened by double-clicking, so you'll start a tiny local web server.

### 1. Add your settings

1. In the Nourish folder, open `js`.
2. Duplicate `config.example.js` and name the copy `config.js`. On a Mac, check that it hasn't become `config.js.txt`.
3. Open `config.js` and replace the two placeholder values with your Project URL and public key. Keep the quote marks.
4. Save the file.

`config.js` is listed in `.gitignore`, so it will never be uploaded to GitHub.

### 2. Start the server

**Mac**

1. Open **Terminal**.
2. Type `cd `, with a space after it.
3. Drag the Nourish folder into the window and press Enter.
4. Run:

   ```
   python3 -m http.server 8000
   ```

**Windows**

1. Open the Nourish folder in File Explorer.
2. Hold Shift, right-click an empty area and choose **Open PowerShell window here** (or **Open in Terminal**).
3. Run:

   ```
   py -m http.server 8000
   ```

If Windows says Python isn't installed, install it from **python.org**, tick **Add python.exe to PATH**, and try again.

### 3. Open the check

1. Go to **http://localhost:8000/setup-check.html** in your browser.
2. You should get green ticks for settings, database and storage.
3. Sign in with the account from Part C. The fourth tick turns green and your targets appear: 1,800 kcal, 160 g protein, and so on.
4. When you've finished, stop the server with **Ctrl + C**.

### If something isn't green

| Message | What to do |
|---|---|
| *js/config.js was not found* | Check the file is called exactly `config.js` and sits in the `js` folder. |
| *Supabase settings are missing* | The placeholder text is still in `config.js`. Replace both values. |
| *That is a SECRET key* or *service_role key* | You copied the wrong key. Use the publishable or anon key. If the secret key was shared anywhere, rotate it in Project Settings → API Keys. |
| *Couldn't reach …* | Check the Project URL for typos and that you're online. Also check the project isn't paused (Part A). |
| *Nourish isn't installed in this database yet* | Run Part B. Make sure it's the same project as the URL in `config.js`. |
| *Email or password is incorrect* | No data exists yet, so the simplest fix is to delete the user in Authentication → Users and create it again. |
| *This email address hasn't been confirmed* | Recreate the user with **Auto Confirm User** ticked. |
| *Expected to see exactly your own profile…* | Run the setup script again. It adds any missing profiles. |
| Page is blank or nothing happens | Make sure the address starts `http://localhost:8000`, not `file://`. The page also needs internet access to load the Supabase library. |

---

## Part G – Report back

When all four ticks are green, reply **"Stage 1 checks passed"**. No keys are needed.

If something failed, include the message shown on the page.

---

### For developers: Supabase CLI

If you already use the Supabase CLI, `supabase/migrations/001`–`004` are the same SQL as the combined script, in order, and can be applied with `supabase db push` after `supabase init` and `supabase link`.

The SQL Editor route above is the recommended one. Don't run both.
