# Putting Nourish on GitHub

Keeping the project on GitHub from the start gives you a history of every change. In Stage 5 it also lets Netlify redeploy automatically whenever you push.

Make the repository **private**. Nothing secret is in it, but it describes your personal app.

## Before you start

Check that `js/config.js` is not going to be uploaded. It's listed in `.gitignore`, so Git ignores it automatically. Don't remove that line.

Never commit API keys or `.env` files. If a secret is ever pushed, deleting the commit isn't enough: rotate the key in the service it belongs to.

## Option A – GitHub Desktop (no command line)

1. Install **GitHub Desktop** from desktop.github.com and sign in.
2. Choose **File → Add local repository…** and pick the Nourish folder.
3. When it says the folder isn't a Git repository yet, click **create a repository**, then **Create repository**.
4. In the list of changed files, confirm that `js/config.js` is **not** there.
5. Type the summary "Stage 1: architecture and database" and click **Commit to main**.
6. Click **Publish repository**, keep **Keep this code private** ticked, and click **Publish**.

## Option B – Command line

1. On github.com, create a **New repository** called `nourish`. Set it to **Private**, and don't add a README or .gitignore, because the project already has them.
2. In a terminal inside the Nourish folder, run:

   ```
   git init
   git add .
   git status
   git commit -m "Stage 1: architecture and database"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/nourish.git
   git push -u origin main
   ```

   When you run `git status`, check that `js/config.js` is not listed before you commit.

## After each stage

Copy the updated files into the folder, check the changes in GitHub Desktop (or with `git status`), commit with a short description, and push.

Connecting the repository to Netlify is covered in `docs/NETLIFY_DEPLOYMENT.md`, which arrives in Stage 5.
