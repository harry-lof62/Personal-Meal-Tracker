# Nourish

A personal nutrition tracker with AI food-label scanning and a nutrition assistant.

- **Website:** plain HTML, CSS and JavaScript, hosted on Netlify.
- **Back end:** Supabase (Postgres, Auth, Storage, Edge Functions).
- **AI:** Anthropic's Claude API, called only from server-side Edge Functions.

## Status

**Stage 1 of 5 – architecture and database: complete, awaiting your Supabase project.**

| Stage | Scope |
|---|---|
| 1 ✅ | Architecture, repository, SQL migrations, Supabase setup, connection check |
| 2 | Design system, sign-in and password reset, dashboard, food diary, food library |
| 3 | Anthropic setup, Edge Functions, label scanner, AI assistant |
| 4 | Weight tracking, progress charts, recipes, meal planning |
| 5 | Full testing, GitHub and Netlify deployment, final documentation |

## Getting started

1. **Supabase:** follow [`docs/SUPABASE_SETUP.md`](docs/SUPABASE_SETUP.md). It covers creating the project, installing the database, creating your login and running the connection check.
2. **GitHub (optional now, required in Stage 5):** follow [`docs/GITHUB_SETUP.md`](docs/GITHUB_SETUP.md).
3. **Design decisions:** see [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Repository layout

```
nourish/
├── setup-check.html            Connection check page (kept as a diagnostic tool)
├── netlify.toml                Build, page-refresh routing, security headers
├── package.json                Test and build commands only – no runtime dependencies
├── assets/
│   ├── logo.svg
│   └── icons/                  App and home-screen icons
├── css/
│   └── styles.css              Design tokens and styles
├── js/
│   ├── supabase.js             Supabase client; refuses secret keys
│   ├── calculations.js         All nutrition maths (mirrors the database)
│   ├── format.js               UK formats: kcal, g, kg / st, DD/MM/YYYY, local dates
│   ├── setup-check.js          Logic for setup-check.html
│   └── config.example.js       Copy to config.js for local use (git-ignored)
├── supabase/
│   ├── migrations/
│   │   ├── 001_initial_schema.sql
│   │   ├── 002_rls_policies.sql
│   │   ├── 003_functions_triggers.sql
│   │   └── 004_storage.sql
│   ├── setup/
│   │   └── nourish_complete_setup.sql   All migrations in one script for the SQL Editor
│   └── tests/                  Local-only database tests
├── scripts/
│   ├── build.mjs               Netlify build: copies the site to dist/, writes config.js
│   ├── build-setup-sql.sh      Regenerates the combined setup script
│   └── test-database.sh        Runs the database tests on a local PostgreSQL
├── tests/                      JavaScript unit tests
└── docs/
```

Stage 2 adds `index.html`, `manifest.json`, `sw.js` and the screen modules (`auth.js`, `dashboard.js`, `diary.js`, `food-library.js`, `settings.js`). Stage 3 adds `supabase/functions/` with `scan-food-label`, `nutrition-assistant` and `meal-suggestions`.

## Security in brief

- **The browser only ever has the public Supabase key.** Secret and service-role keys are rejected by the browser and by the Netlify build.
- **Every personal table has Row Level Security.** Each user can reach only their own rows, signed-out visitors can reach none, and photos are in private buckets inside a per-user folder.
- **Edge Functions act as the signed-in user.** No service-role key is used anywhere. The Anthropic key lives only in Supabase secrets.
- **AI results are never saved without approval.** The database itself rejects an AI-scanned food that hasn't been approved.

## Testing

| Command | What it checks |
|---|---|
| `npm test` | JavaScript unit tests: nutrition maths, UK formatting and dates, key validation. Needs Node 20+. |
| `npm run test:db` | Applies every migration twice on a local PostgreSQL 15+, then runs the database tests. |

The database tests cover these areas:

- portion calculations;
- historical snapshots;
- deletion rules;
- recipes;
- weight sync;
- targets by date;
- isolation between two users;
- signed-out access;
- storage folder rules.

They need `psql`, `createdb` and `dropdb`, and they never touch your Supabase project. Use `PGUSER` and similar environment variables to point them at a local server.

If you change a migration, regenerate the combined script with `npm run build:sql`.

## Conventions

- **Units:** UK. Dates are DD/MM/YYYY, energy is in kcal, and food is in grams and millilitres. Weight is stored in kilograms and can be shown in kg, lb or stones and pounds.
- **Nutrition values:** stored per 100 g or 100 ml. Unknown values are stored as empty (`NULL`), never as zero.
- **Rounding:** happens only on screen. Stored values keep full precision.

## Data sources

From Stage 2, barcode lookups use **Open Food Facts** (openfoodfacts.org). Its data is available under the Open Database Licence. Products saved from it are marked with their source, and the app shows attribution.
