-- =============================================================================
-- Nourish – 004_storage.sql
-- Two PRIVATE buckets. Files live under "<user id>/..." and only that user can
-- read, upload, replace or delete them. The app shows images via short-lived
-- signed URLs. Safe to re-run.
--
-- Claude's vision API accepts JPEG, PNG, GIF and WebP, so the app converts
-- phone photos (including iPhone HEIC) to JPEG before upload.
-- =============================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('label-scans', 'label-scans', false, 10485760, array['image/jpeg','image/png','image/webp']),
  ('food-photos', 'food-photos', false,  5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update
  set public             = false,
      file_size_limit    = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists nourish_storage_select_own on storage.objects;
drop policy if exists nourish_storage_insert_own on storage.objects;
drop policy if exists nourish_storage_update_own on storage.objects;
drop policy if exists nourish_storage_delete_own on storage.objects;

create policy nourish_storage_select_own on storage.objects
  for select to authenticated
  using (bucket_id in ('label-scans','food-photos')
         and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy nourish_storage_insert_own on storage.objects
  for insert to authenticated
  with check (bucket_id in ('label-scans','food-photos')
              and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy nourish_storage_update_own on storage.objects
  for update to authenticated
  using (bucket_id in ('label-scans','food-photos')
         and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id in ('label-scans','food-photos')
              and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy nourish_storage_delete_own on storage.objects
  for delete to authenticated
  using (bucket_id in ('label-scans','food-photos')
         and (storage.foldername(name))[1] = (select auth.uid())::text);
