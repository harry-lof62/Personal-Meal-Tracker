-- =============================================================================
-- Nourish – 003_functions_triggers.sql
-- Triggers that protect data integrity, views for totals, and RPC functions.
-- Safe to re-run: CREATE OR REPLACE for functions/views, DROP/CREATE for triggers.
--
-- All functions use SECURITY INVOKER (Row Level Security still applies) except
-- handle_new_user and nourish_health_check, which are explained inline.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- updated_at maintenance
-- -----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array[
    'profiles','nutrition_targets','foods','recipes','recipe_ingredients',
    'food_diary','weight_entries','food_images','ai_drafts'
  ] loop
    execute format('drop trigger if exists %I on public.%I', t || '_set_updated_at', t);
    execute format('create trigger %I before update on public.%I
                    for each row execute function public.set_updated_at()', t || '_set_updated_at', t);
  end loop;
end
$$;

-- -----------------------------------------------------------------------------
-- New user → profile + default nutrition targets
-- SECURITY DEFINER because it runs inside Supabase Auth's sign-up transaction,
-- where there is no signed-in user yet. It only ever writes rows for NEW.id.
-- -----------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (user_id, display_name)
  values (new.id, nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''))
  on conflict (user_id) do nothing;

  -- Initial, editable defaults: 1,800 kcal / 160 g protein / 150 g carbs /
  -- 60 g fat / 30 g fibre / 6 g salt (maximum).
  insert into public.nutrition_targets (user_id, effective_from)
  values (new.id, current_date)
  on conflict (user_id, effective_from) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Backfill: users created before this script ran still get a profile + targets.
insert into public.profiles (user_id)
select u.id from auth.users u
on conflict (user_id) do nothing;

insert into public.nutrition_targets (user_id, effective_from)
select u.id, current_date
from auth.users u
where not exists (select 1 from public.nutrition_targets t where t.user_id = u.id);

-- -----------------------------------------------------------------------------
-- foods: tidy text and barcodes before saving
-- -----------------------------------------------------------------------------
create or replace function public.foods_normalise()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.name     := btrim(new.name);
  new.brand    := nullif(btrim(new.brand), '');
  new.category := nullif(btrim(new.category), '');
  new.barcode  := nullif(regexp_replace(coalesce(new.barcode, ''), '[\s-]', '', 'g'), '');
  return new;
end;
$$;

drop trigger if exists foods_normalise on public.foods;
create trigger foods_normalise
  before insert or update on public.foods
  for each row execute function public.foods_normalise();

-- -----------------------------------------------------------------------------
-- recipe_nutrition view – deterministic totals from ingredient quantities.
-- Uses CURRENT food values (recipes are live). Diary entries snapshot them.
-- ingredients_missing_data > 0 means some totals are incomplete.
-- -----------------------------------------------------------------------------
create or replace view public.recipe_nutrition
with (security_invoker = true) as
select
  r.id        as recipe_id,
  r.user_id,
  r.name,
  r.portions,
  count(ri.id)::integer as ingredient_count,
  count(ri.id) filter (where
      f.energy_kcal_100 is null or f.protein_g_100 is null or f.carbs_g_100 is null
   or f.fat_g_100 is null or f.fibre_g_100 is null or f.salt_g_100 is null)::integer
    as ingredients_missing_data,
  sum(ri.quantity * f.energy_kcal_100 / 100) as total_energy_kcal,
  sum(ri.quantity * f.protein_g_100   / 100) as total_protein_g,
  sum(ri.quantity * f.carbs_g_100     / 100) as total_carbs_g,
  sum(ri.quantity * f.sugars_g_100    / 100) as total_sugars_g,
  sum(ri.quantity * f.fat_g_100       / 100) as total_fat_g,
  sum(ri.quantity * f.sat_fat_g_100   / 100) as total_sat_fat_g,
  sum(ri.quantity * f.fibre_g_100     / 100) as total_fibre_g,
  sum(ri.quantity * f.salt_g_100      / 100) as total_salt_g,
  sum(ri.quantity * f.energy_kcal_100 / 100) / r.portions as portion_energy_kcal,
  sum(ri.quantity * f.protein_g_100   / 100) / r.portions as portion_protein_g,
  sum(ri.quantity * f.carbs_g_100     / 100) / r.portions as portion_carbs_g,
  sum(ri.quantity * f.sugars_g_100    / 100) / r.portions as portion_sugars_g,
  sum(ri.quantity * f.fat_g_100       / 100) / r.portions as portion_fat_g,
  sum(ri.quantity * f.sat_fat_g_100   / 100) / r.portions as portion_sat_fat_g,
  sum(ri.quantity * f.fibre_g_100     / 100) / r.portions as portion_fibre_g,
  sum(ri.quantity * f.salt_g_100      / 100) / r.portions as portion_salt_g
from public.recipes r
left join public.recipe_ingredients ri on ri.recipe_id = r.id
left join public.foods f              on f.id = ri.food_id
group by r.id, r.user_id, r.name, r.portions;

-- -----------------------------------------------------------------------------
-- food_diary: take the nutrition snapshot
--   * INSERT with food_id   → copy name/brand/per-100 values from foods
--   * INSERT with recipe_id → copy per-portion values from recipe_nutrition
--   * INSERT with neither   → manual quick-add; caller supplies the snapshot
--   * UPDATE                → snapshot is kept; only re-taken if the entry is
--                             pointed at a different food/recipe
--   * Food/recipe deleted   → FK sets the id to NULL; snapshot is untouched
-- -----------------------------------------------------------------------------
create or replace function public.food_diary_apply_snapshot()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  f  public.foods%rowtype;
  rn record;
begin
  if tg_op = 'UPDATE' then
    if new.food_id is not distinct from old.food_id
       and new.recipe_id is not distinct from old.recipe_id then
      if new.quantity_unit is distinct from old.quantity_unit
         and (new.food_id is not null or new.recipe_id is not null) then
        raise exception 'The unit of a logged food cannot be changed; change the quantity instead'
          using errcode = '22023';
      end if;
      return new;
    end if;
    if new.food_id is null and new.recipe_id is null then
      return new;  -- source detached (e.g. food deleted): keep the snapshot
    end if;
  end if;

  if new.food_id is not null then
    select * into f from public.foods where id = new.food_id;
    if not found or f.user_id <> new.user_id then
      raise exception 'Food % was not found in your library', new.food_id using errcode = '23503';
    end if;
    if new.quantity_unit <> f.base_unit then
      raise exception '% is measured in %, not %', f.name, f.base_unit, new.quantity_unit
        using errcode = '22023';
    end if;
    new.item_name        := f.name;
    new.item_brand       := f.brand;
    new.snap_energy_kcal := f.energy_kcal_100;
    new.snap_protein_g   := f.protein_g_100;
    new.snap_carbs_g     := f.carbs_g_100;
    new.snap_sugars_g    := f.sugars_g_100;
    new.snap_fat_g       := f.fat_g_100;
    new.snap_sat_fat_g   := f.sat_fat_g_100;
    new.snap_fibre_g     := f.fibre_g_100;
    new.snap_salt_g      := f.salt_g_100;

  elsif new.recipe_id is not null then
    select * into rn from public.recipe_nutrition where recipe_id = new.recipe_id;
    if not found or rn.user_id <> new.user_id then
      raise exception 'Recipe % was not found', new.recipe_id using errcode = '23503';
    end if;
    if rn.ingredient_count = 0 then
      raise exception 'Recipe "%" has no ingredients yet', rn.name using errcode = '22023';
    end if;
    if new.quantity_unit <> 'portion' then
      raise exception 'Recipes are logged in portions' using errcode = '22023';
    end if;
    new.item_name        := rn.name;
    new.item_brand       := null;
    new.snap_energy_kcal := round(rn.portion_energy_kcal, 2);
    new.snap_protein_g   := round(rn.portion_protein_g, 3);
    new.snap_carbs_g     := round(rn.portion_carbs_g, 3);
    new.snap_sugars_g    := round(rn.portion_sugars_g, 3);
    new.snap_fat_g       := round(rn.portion_fat_g, 3);
    new.snap_sat_fat_g   := round(rn.portion_sat_fat_g, 3);
    new.snap_fibre_g     := round(rn.portion_fibre_g, 3);
    new.snap_salt_g      := round(rn.portion_salt_g, 3);
  end if;

  return new;
end;
$$;

drop trigger if exists food_diary_apply_snapshot on public.food_diary;
create trigger food_diary_apply_snapshot
  before insert or update on public.food_diary
  for each row execute function public.food_diary_apply_snapshot();

-- -----------------------------------------------------------------------------
-- recipe_ingredients: recipe and food must belong to the same user, unit must
-- match the food's base unit.
-- -----------------------------------------------------------------------------
create or replace function public.recipe_ingredients_validate()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  recipe_owner uuid;
  food_owner   uuid;
  food_unit    text;
  food_name    text;
begin
  select user_id into recipe_owner from public.recipes where id = new.recipe_id;
  if recipe_owner is null or recipe_owner <> new.user_id then
    raise exception 'Recipe % was not found', new.recipe_id using errcode = '23503';
  end if;

  select user_id, base_unit, name into food_owner, food_unit, food_name
  from public.foods where id = new.food_id;
  if food_owner is null or food_owner <> new.user_id then
    raise exception 'Food % was not found in your library', new.food_id using errcode = '23503';
  end if;

  if new.unit <> food_unit then
    raise exception '% is measured in %, not %', food_name, food_unit, new.unit using errcode = '22023';
  end if;
  return new;
end;
$$;

drop trigger if exists recipe_ingredients_validate on public.recipe_ingredients;
create trigger recipe_ingredients_validate
  before insert or update on public.recipe_ingredients
  for each row execute function public.recipe_ingredients_validate();

-- -----------------------------------------------------------------------------
-- weight_entries → profiles.current_weight_kg (latest entry) and
-- start_weight_kg (first entry, only if not already set).
-- Historical weight entries are never modified.
-- -----------------------------------------------------------------------------
create or replace function public.weight_entries_sync_profile()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
  uid      uuid;
  latest   numeric;
  earliest numeric;
begin
  if tg_op = 'DELETE' then uid := old.user_id; else uid := new.user_id; end if;

  select w.weight_kg into latest
  from public.weight_entries w where w.user_id = uid
  order by w.entry_date desc limit 1;

  if latest is not null then
    select w.weight_kg into earliest
    from public.weight_entries w where w.user_id = uid
    order by w.entry_date asc limit 1;

    update public.profiles p
       set current_weight_kg = latest,
           start_weight_kg   = coalesce(p.start_weight_kg, earliest)
     where p.user_id = uid;
  end if;
  return null;
end;
$$;

drop trigger if exists weight_entries_sync_profile on public.weight_entries;
create trigger weight_entries_sync_profile
  after insert or update or delete on public.weight_entries
  for each row execute function public.weight_entries_sync_profile();

-- -----------------------------------------------------------------------------
-- ai_drafts: stamp the decision time automatically
-- -----------------------------------------------------------------------------
create or replace function public.ai_drafts_stamp_decision()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.status = 'pending' then
    new.decided_at := null;
  elsif tg_op = 'INSERT' or old.status is distinct from new.status then
    new.decided_at := coalesce(new.decided_at, now());
  end if;
  return new;
end;
$$;

drop trigger if exists ai_drafts_stamp_decision on public.ai_drafts;
create trigger ai_drafts_stamp_decision
  before insert or update on public.ai_drafts
  for each row execute function public.ai_drafts_stamp_decision();

-- -----------------------------------------------------------------------------
-- daily_nutrition_totals view – used by the Edge Functions to give Claude
-- facts. The browser computes the same totals in js/calculations.js.
-- entries_missing_* > 0 means a total is a lower bound, not exact.
-- -----------------------------------------------------------------------------
create or replace view public.daily_nutrition_totals
with (security_invoker = true) as
select
  d.user_id,
  d.entry_date,
  count(*)::integer as entry_count,
  sum(d.energy_kcal) as energy_kcal,
  sum(d.protein_g)   as protein_g,
  sum(d.carbs_g)     as carbs_g,
  sum(d.sugars_g)    as sugars_g,
  sum(d.fat_g)       as fat_g,
  sum(d.sat_fat_g)   as sat_fat_g,
  sum(d.fibre_g)     as fibre_g,
  sum(d.salt_g)      as salt_g,
  count(*) filter (where d.energy_kcal is null)::integer as entries_missing_energy,
  count(*) filter (where d.protein_g is null or d.carbs_g is null or d.fat_g is null
                      or d.fibre_g is null or d.salt_g is null)::integer as entries_missing_nutrients
from public.food_diary d
group by d.user_id, d.entry_date;

-- =============================================================================
-- RPC functions (callable from the app with supabase.rpc)
-- =============================================================================

-- Targets in force on a date: the latest row on or before it, otherwise the
-- earliest row after it.
create or replace function public.get_nutrition_targets(p_date date default current_date)
returns public.nutrition_targets
language sql
stable
set search_path = ''
as $$
  select t.*
  from public.nutrition_targets t
  where t.user_id = (select auth.uid())
  order by (t.effective_from <= p_date) desc,
           abs(t.effective_from - p_date) asc
  limit 1;
$$;

-- Food library search: substring + fuzzy match, favourites first.
create or replace function public.search_foods(p_query text, p_limit integer default 25)
returns setof public.foods
language sql
stable
set search_path = ''
as $$
  with q as (
    select lower(btrim(coalesce(p_query, ''))) as term
  ), q2 as (
    select term,
           replace(replace(replace(term, '\', '\\'), '%', '\%'), '_', '\_') as escaped
    from q
  )
  select f.*
  from public.foods f, q2
  where f.user_id = (select auth.uid())
    and f.archived_at is null
    and (
         q2.term = ''
      or f.search_text like '%' || q2.escaped || '%'
      or f.barcode = q2.term
      or extensions.word_similarity(q2.term, f.search_text) > 0.45
    )
  order by f.is_favourite desc,
           (q2.term <> '' and f.search_text like q2.escaped || '%') desc,
           extensions.word_similarity(q2.term, f.search_text) desc,
           f.name asc
  limit least(greatest(coalesce(p_limit, 25), 1), 100);
$$;

-- Duplicate check used by the scanner before saving a product.
create or replace function public.find_similar_foods(
  p_name text, p_brand text default null, p_barcode text default null)
returns table (id uuid, name text, brand text, barcode text, match_reason text, score real)
language sql
stable
set search_path = ''
as $$
  with input as (
    select lower(btrim(coalesce(p_name, '')) || ' ' || coalesce(btrim(p_brand), '')) as label,
           nullif(regexp_replace(coalesce(p_barcode, ''), '[\s-]', '', 'g'), '') as code
  )
  select f.id, f.name, f.brand, f.barcode,
         case when i.code is not null and f.barcode = i.code then 'barcode' else 'name' end,
         case when i.code is not null and f.barcode = i.code then 1.0::real
              else extensions.similarity(lower(f.name || ' ' || coalesce(f.brand, '')), i.label) end
  from public.foods f, input i
  where f.user_id = (select auth.uid())
    and f.archived_at is null
    and (
         (i.code is not null and f.barcode = i.code)
      or extensions.similarity(lower(f.name || ' ' || coalesce(f.brand, '')), i.label) > 0.45
    )
  order by 6 desc
  limit 5;
$$;

-- Copy a meal from one day to another. Items linked to a food or recipe take
-- that food's CURRENT values (via the snapshot trigger); manual items keep
-- their recorded values. Returns the number of items copied.
create or replace function public.copy_meal(
  p_from_date date, p_from_meal text, p_to_date date, p_to_meal text default null)
returns integer
language plpgsql
set search_path = ''
as $$
declare
  target_meal text := coalesce(p_to_meal, p_from_meal);
  start_pos   integer;
  copied      integer;
begin
  if p_from_meal not in ('breakfast','lunch','dinner','snacks')
     or target_meal not in ('breakfast','lunch','dinner','snacks') then
    raise exception 'Meal must be breakfast, lunch, dinner or snacks' using errcode = '22023';
  end if;

  select coalesce(max(position) + 1, 0) into start_pos
  from public.food_diary
  where user_id = (select auth.uid()) and entry_date = p_to_date and meal = target_meal;

  insert into public.food_diary (
    user_id, entry_date, meal, position, food_id, recipe_id, quantity, quantity_unit,
    serving_label, item_name, item_brand, snap_energy_kcal, snap_protein_g, snap_carbs_g,
    snap_sugars_g, snap_fat_g, snap_sat_fat_g, snap_fibre_g, snap_salt_g, note)
  select
    d.user_id, p_to_date, target_meal,
    start_pos + (row_number() over (order by d.position, d.created_at))::integer - 1,
    d.food_id, d.recipe_id, d.quantity, d.quantity_unit, d.serving_label,
    d.item_name, d.item_brand, d.snap_energy_kcal, d.snap_protein_g, d.snap_carbs_g,
    d.snap_sugars_g, d.snap_fat_g, d.snap_sat_fat_g, d.snap_fibre_g, d.snap_salt_g, d.note
  from public.food_diary d
  where d.user_id = (select auth.uid())
    and d.entry_date = p_from_date
    and d.meal = p_from_meal;

  get diagnostics copied = row_count;
  return copied;
end;
$$;

-- Explicit, user-requested refresh of one diary entry's snapshot from the
-- current food/recipe (e.g. after correcting a mis-scanned label).
create or replace function public.refresh_diary_entry_snapshot(p_entry_id uuid)
returns public.food_diary
language plpgsql
set search_path = ''
as $$
declare
  entry public.food_diary%rowtype;
  f     public.foods%rowtype;
  rn    record;
begin
  select * into entry from public.food_diary
  where id = p_entry_id and user_id = (select auth.uid());
  if not found then
    raise exception 'Diary entry not found' using errcode = 'P0002';
  end if;

  if entry.food_id is not null then
    select * into f from public.foods where id = entry.food_id;
    update public.food_diary set
      item_name = f.name, item_brand = f.brand,
      snap_energy_kcal = f.energy_kcal_100, snap_protein_g = f.protein_g_100,
      snap_carbs_g = f.carbs_g_100, snap_sugars_g = f.sugars_g_100,
      snap_fat_g = f.fat_g_100, snap_sat_fat_g = f.sat_fat_g_100,
      snap_fibre_g = f.fibre_g_100, snap_salt_g = f.salt_g_100
    where id = entry.id
    returning * into entry;
  elsif entry.recipe_id is not null then
    select * into rn from public.recipe_nutrition where recipe_id = entry.recipe_id;
    update public.food_diary set
      item_name = rn.name,
      snap_energy_kcal = round(rn.portion_energy_kcal, 2), snap_protein_g = round(rn.portion_protein_g, 3),
      snap_carbs_g = round(rn.portion_carbs_g, 3), snap_sugars_g = round(rn.portion_sugars_g, 3),
      snap_fat_g = round(rn.portion_fat_g, 3), snap_sat_fat_g = round(rn.portion_sat_fat_g, 3),
      snap_fibre_g = round(rn.portion_fibre_g, 3), snap_salt_g = round(rn.portion_salt_g, 3)
    where id = entry.id
    returning * into entry;
  else
    raise exception 'This entry is not linked to a food or recipe' using errcode = '22023';
  end if;

  return entry;
end;
$$;

-- -----------------------------------------------------------------------------
-- Health check for the setup page. Callable while signed out.
-- SECURITY DEFINER so it can read catalog/bucket metadata. It returns only
-- structural facts (do the tables exist, is RLS on) – never any user data.
-- -----------------------------------------------------------------------------
create or replace function public.nourish_health_check()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'app', 'nourish',
    'schema_version', 1,
    'tables', (
      select jsonb_object_agg(t.name, jsonb_build_object(
               'exists', c.oid is not null,
               'rls',    coalesce(c.relrowsecurity, false)))
      from unnest(array['profiles','nutrition_targets','foods','food_diary',
                        'weight_entries','recipes','recipe_ingredients',
                        'ai_interactions','ai_drafts','food_images']) as t(name)
      left join pg_catalog.pg_class c on c.oid = pg_catalog.to_regclass('public.' || t.name)
    ),
    'buckets', (
      select coalesce(jsonb_agg(jsonb_build_object('id', b.id, 'public', b.public) order by b.id), '[]'::jsonb)
      from storage.buckets b
      where b.id in ('label-scans', 'food-photos')
    ),
    'checked_at', now()
  );
$$;

-- =============================================================================
-- Privileges
-- =============================================================================
-- Trigger functions are never called directly.
revoke all on function public.set_updated_at()               from public, anon, authenticated;
revoke all on function public.handle_new_user()              from public, anon, authenticated;
revoke all on function public.foods_normalise()              from public, anon, authenticated;
revoke all on function public.food_diary_apply_snapshot()    from public, anon, authenticated;
revoke all on function public.recipe_ingredients_validate()  from public, anon, authenticated;
revoke all on function public.weight_entries_sync_profile()  from public, anon, authenticated;
revoke all on function public.ai_drafts_stamp_decision()     from public, anon, authenticated;

-- RPCs: signed-in users only (RLS still applies inside them).
revoke all on function public.get_nutrition_targets(date)                 from public, anon;
revoke all on function public.search_foods(text, integer)                 from public, anon;
revoke all on function public.find_similar_foods(text, text, text)        from public, anon;
revoke all on function public.copy_meal(date, text, date, text)           from public, anon;
revoke all on function public.refresh_diary_entry_snapshot(uuid)          from public, anon;
grant execute on function public.get_nutrition_targets(date)              to authenticated;
grant execute on function public.search_foods(text, integer)              to authenticated;
grant execute on function public.find_similar_foods(text, text, text)     to authenticated;
grant execute on function public.copy_meal(date, text, date, text)        to authenticated;
grant execute on function public.refresh_diary_entry_snapshot(uuid)       to authenticated;

revoke all on function public.nourish_health_check() from public;
grant execute on function public.nourish_health_check() to anon, authenticated;

-- Views
revoke all on public.recipe_nutrition       from public, anon;
revoke all on public.daily_nutrition_totals from public, anon;
grant select on public.recipe_nutrition       to authenticated;
grant select on public.daily_nutrition_totals to authenticated;
