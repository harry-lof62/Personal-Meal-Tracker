-- =============================================================================
-- Nourish – 002_rls_policies.sql
-- Row Level Security: a signed-in user can only ever see or change rows where
-- user_id = their own id. The anon (signed-out) role gets no table access.
-- Safe to re-run: policies are dropped and recreated.
-- =============================================================================

do $$
declare
  t text;
  -- Tables with full owner CRUD
  crud_tables text[] := array[
    'nutrition_targets','foods','recipes','recipe_ingredients',
    'food_diary','weight_entries','food_images','ai_drafts'
  ];
  all_tables text[] := crud_tables || array['profiles','ai_interactions'];
begin
  foreach t in array all_tables loop
    execute format('alter table public.%I enable row level security', t);

    -- Signed-out visitors: nothing. Signed-in users: table privileges only;
    -- the policies below decide which rows.
    execute format('revoke all on table public.%I from anon', t);
    execute format('revoke all on table public.%I from public', t);

    execute format('drop policy if exists %I on public.%I', t || '_select_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_insert_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_update_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_delete_own', t);

    execute format($p$create policy %I on public.%I for select to authenticated
                     using (user_id = (select auth.uid()))$p$, t || '_select_own', t);
    execute format($p$create policy %I on public.%I for insert to authenticated
                     with check (user_id = (select auth.uid()))$p$, t || '_insert_own', t);
  end loop;

  -- Update + delete for the CRUD tables
  foreach t in array crud_tables loop
    execute format('grant select, insert, update, delete on table public.%I to authenticated', t);
    execute format($p$create policy %I on public.%I for update to authenticated
                     using (user_id = (select auth.uid()))
                     with check (user_id = (select auth.uid()))$p$, t || '_update_own', t);
    execute format($p$create policy %I on public.%I for delete to authenticated
                     using (user_id = (select auth.uid()))$p$, t || '_delete_own', t);
  end loop;
end
$$;

-- profiles: read, create and edit your own; no deleting (account deletion cascades)
revoke all on table public.profiles from authenticated;
grant select, insert, update on table public.profiles to authenticated;
create policy profiles_update_own on public.profiles for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- ai_interactions: an append-only audit log. Read, add and delete; never edit.
revoke all on table public.ai_interactions from authenticated;
grant select, insert, delete on table public.ai_interactions to authenticated;
create policy ai_interactions_delete_own on public.ai_interactions for delete to authenticated
  using (user_id = (select auth.uid()));

-- Note: every UPDATE policy has WITH CHECK (user_id = auth.uid()), so a row can
-- never be reassigned to another user.
