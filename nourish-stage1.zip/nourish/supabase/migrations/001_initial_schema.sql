-- =============================================================================
-- Nourish – 001_initial_schema.sql
-- Tables, constraints and indexes.
--
-- Safe to re-run: every object is created with IF NOT EXISTS.
-- Conventions
--   * UUID primary keys (gen_random_uuid()).
--   * Every personal table has user_id → auth.users(id).
--   * All weights stored in kilograms, all food quantities in g / ml.
--   * Nutrition per 100 g (or per 100 ml when base_unit = 'ml').
--   * NULL nutrition means "unknown", never zero. Nothing is invented.
-- =============================================================================

create extension if not exists pgcrypto with schema extensions;
create extension if not exists pg_trgm  with schema extensions;

-- -----------------------------------------------------------------------------
-- 1. profiles – one row per user
-- -----------------------------------------------------------------------------
create table if not exists public.profiles (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null unique default auth.uid()
                      references auth.users (id) on delete cascade,
  display_name      text check (char_length(display_name) <= 80),
  date_of_birth     date check (date_of_birth > date '1900-01-01'),
  height_cm         numeric(5,1) check (height_cm between 50 and 272),
  current_weight_kg numeric(5,2) check (current_weight_kg between 20 and 400),
  start_weight_kg   numeric(5,2) check (start_weight_kg between 20 and 400),
  target_weight_kg  numeric(5,2) check (target_weight_kg between 20 and 400),
  activity_level    text check (activity_level in
                      ('sedentary','light','moderate','active','very_active')),
  weight_unit       text not null default 'kg'
                      check (weight_unit in ('kg','lb','st_lb')),
  height_unit       text not null default 'cm'
                      check (height_unit in ('cm','ft_in')),
  date_format       text not null default 'DD/MM/YYYY'
                      check (date_format in ('DD/MM/YYYY','YYYY-MM-DD','MM/DD/YYYY')),
  timezone          text not null default 'Europe/London',
  save_scan_images  boolean not null default false,   -- consent to keep label photos
  onboarded_at      timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
comment on table public.profiles is 'Personal profile and display preferences. Weights always stored in kg.';
comment on column public.profiles.current_weight_kg is 'Kept in sync with the latest weight_entries row by trigger.';

-- -----------------------------------------------------------------------------
-- 2. nutrition_targets – dated, so past days are judged against past targets
-- -----------------------------------------------------------------------------
create table if not exists public.nutrition_targets (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null default auth.uid()
                    references auth.users (id) on delete cascade,
  effective_from  date not null default current_date,
  energy_kcal     numeric(6,1) not null default 1800 check (energy_kcal between 500 and 10000),
  protein_g       numeric(6,1) not null default 160  check (protein_g  between 0 and 1000),
  carbs_g         numeric(6,1) not null default 150  check (carbs_g    between 0 and 1500),
  fat_g           numeric(6,1) not null default 60   check (fat_g      between 0 and 1000),
  fibre_g         numeric(6,1) not null default 30   check (fibre_g    between 0 and 200),
  salt_g          numeric(5,2) not null default 6    check (salt_g     between 0 and 50),
  sugars_g        numeric(6,1) check (sugars_g between 0 and 1000),
  sat_fat_g       numeric(6,1) check (sat_fat_g between 0 and 500),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (user_id, effective_from)
);
comment on table public.nutrition_targets is 'Targets apply from effective_from until the next row. Salt is a maximum.';

-- -----------------------------------------------------------------------------
-- 3. foods – the reusable food library
-- -----------------------------------------------------------------------------
create table if not exists public.foods (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid()
                      references auth.users (id) on delete cascade,
  name              text not null check (char_length(btrim(name)) between 1 and 200),
  brand             text check (char_length(brand) <= 120),
  barcode           text check (barcode ~ '^[0-9]{6,14}$'),
  category          text check (char_length(category) <= 60),
  base_unit         text not null default 'g' check (base_unit in ('g','ml')),

  -- Serving information (amounts in base_unit)
  serving_size      numeric(10,2) check (serving_size > 0 and serving_size < 100000),
  serving_label     text check (char_length(serving_label) <= 80),   -- e.g. '1 bar'
  serving_options   jsonb not null default '[]'::jsonb
                      check (jsonb_typeof(serving_options) = 'array'), -- [{"label":"1 slice","amount":36}]
  package_size      numeric(10,2) check (package_size > 0 and package_size < 100000),

  -- Nutrition per 100 g / 100 ml. NULL = unknown.
  energy_kcal_100   numeric(7,2) check (energy_kcal_100 between 0 and 1000),
  protein_g_100     numeric(7,3) check (protein_g_100   between 0 and 100),
  carbs_g_100       numeric(7,3) check (carbs_g_100     between 0 and 100),
  sugars_g_100      numeric(7,3) check (sugars_g_100    between 0 and 100),
  fat_g_100         numeric(7,3) check (fat_g_100       between 0 and 100),
  sat_fat_g_100     numeric(7,3) check (sat_fat_g_100   between 0 and 100),
  fibre_g_100       numeric(7,3) check (fibre_g_100     between 0 and 100),
  salt_g_100        numeric(7,3) check (salt_g_100      between 0 and 100),

  -- Provenance
  source            text not null default 'manual'
                      check (source in ('manual','ai_scan','open_food_facts')),
  source_reference  text,              -- e.g. Open Food Facts product URL
  label_data        jsonb,             -- original label values/units as read (AI scan)
  ai_confidence     jsonb,             -- per-field confidence from the scanner
  verified_at       timestamptz,       -- when the user approved AI / external data

  is_favourite      boolean not null default false,
  archived_at       timestamptz,       -- soft delete; keeps recipes intact
  search_text       text generated always as
                      (lower(name || ' ' || coalesce(brand, '') || ' ' || coalesce(category, ''))) stored,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),

  -- AI-scanned products can only exist once a person has approved them.
  constraint foods_ai_scan_requires_verification
    check (source <> 'ai_scan' or verified_at is not null)
);
comment on table public.foods is 'Reusable food library. Nutrition per 100 g or 100 ml (base_unit). NULL = unknown.';

-- -----------------------------------------------------------------------------
-- 4. recipes
-- -----------------------------------------------------------------------------
create table if not exists public.recipes (
  id                    uuid primary key default gen_random_uuid(),
  user_id               uuid not null default auth.uid()
                          references auth.users (id) on delete cascade,
  name                  text not null check (char_length(btrim(name)) between 1 and 200),
  description           text check (char_length(description) <= 2000),
  instructions          text check (char_length(instructions) <= 20000),
  portions              numeric(6,2) not null default 1 check (portions > 0 and portions <= 500),
  cooked_weight_g       numeric(10,2) check (cooked_weight_g > 0),
  source                text not null default 'manual' check (source in ('manual','ai_suggestion')),
  is_favourite          boolean not null default false,
  archived_at           timestamptz,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- 5. recipe_ingredients
--    Deleting a recipe removes its ingredient lines (they have no meaning alone).
--    Deleting a food that is used in a recipe is BLOCKED (archive it instead).
-- -----------------------------------------------------------------------------
create table if not exists public.recipe_ingredients (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid()
                references auth.users (id) on delete cascade,
  recipe_id   uuid not null references public.recipes (id) on delete cascade,
  food_id     uuid not null references public.foods (id)   on delete restrict,
  quantity    numeric(10,2) not null check (quantity > 0 and quantity < 100000),
  unit        text not null default 'g' check (unit in ('g','ml')),
  position    integer not null default 0,
  note        text check (char_length(note) <= 200),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- 6. food_diary – every row carries a nutrition SNAPSHOT
--    snap_* = nutrition per 100 g/ml (quantity_unit g/ml) or per portion
--    (quantity_unit 'portion') at the moment the food was logged.
--    Totals are generated columns, so they can never drift from quantity.
-- -----------------------------------------------------------------------------
create table if not exists public.food_diary (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null default auth.uid()
                      references auth.users (id) on delete cascade,
  entry_date        date not null,
  meal              text not null check (meal in ('breakfast','lunch','dinner','snacks')),
  position          integer not null default 0,

  -- Where it came from (both nullable: the snapshot survives deletion)
  food_id           uuid references public.foods (id)   on delete set null,
  recipe_id         uuid references public.recipes (id) on delete set null,

  quantity          numeric(10,2) not null check (quantity > 0 and quantity < 100000),
  quantity_unit     text not null default 'g' check (quantity_unit in ('g','ml','portion')),
  serving_label     text check (char_length(serving_label) <= 80),

  -- Snapshot
  item_name         text not null check (char_length(btrim(item_name)) between 1 and 200),
  item_brand        text,
  snap_energy_kcal  numeric(9,2) check (snap_energy_kcal >= 0),
  snap_protein_g    numeric(9,3) check (snap_protein_g   >= 0),
  snap_carbs_g      numeric(9,3) check (snap_carbs_g     >= 0),
  snap_sugars_g     numeric(9,3) check (snap_sugars_g    >= 0),
  snap_fat_g        numeric(9,3) check (snap_fat_g       >= 0),
  snap_sat_fat_g    numeric(9,3) check (snap_sat_fat_g   >= 0),
  snap_fibre_g      numeric(9,3) check (snap_fibre_g     >= 0),
  snap_salt_g       numeric(9,3) check (snap_salt_g      >= 0),

  -- Totals for this line (deterministic: snapshot × quantity ÷ basis)
  energy_kcal numeric generated always as (snap_energy_kcal * quantity / (case when quantity_unit = 'portion' then 1 else 100 end)) stored,
  protein_g   numeric generated always as (snap_protein_g   * quantity / (case when quantity_unit = 'portion' then 1 else 100 end)) stored,
  carbs_g     numeric generated always as (snap_carbs_g     * quantity / (case when quantity_unit = 'portion' then 1 else 100 end)) stored,
  sugars_g    numeric generated always as (snap_sugars_g    * quantity / (case when quantity_unit = 'portion' then 1 else 100 end)) stored,
  fat_g       numeric generated always as (snap_fat_g       * quantity / (case when quantity_unit = 'portion' then 1 else 100 end)) stored,
  sat_fat_g   numeric generated always as (snap_sat_fat_g   * quantity / (case when quantity_unit = 'portion' then 1 else 100 end)) stored,
  fibre_g     numeric generated always as (snap_fibre_g     * quantity / (case when quantity_unit = 'portion' then 1 else 100 end)) stored,
  salt_g      numeric generated always as (snap_salt_g      * quantity / (case when quantity_unit = 'portion' then 1 else 100 end)) stored,

  note              text check (char_length(note) <= 500),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),

  constraint food_diary_single_source check (food_id is null or recipe_id is null)
);
comment on table public.food_diary is 'Diary lines with an immutable nutrition snapshot taken when logged.';

-- -----------------------------------------------------------------------------
-- 7. weight_entries – one per day, always kg
-- -----------------------------------------------------------------------------
create table if not exists public.weight_entries (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid()
                references auth.users (id) on delete cascade,
  entry_date  date not null,
  weight_kg   numeric(5,2) not null check (weight_kg between 20 and 400),
  note        text check (char_length(note) <= 500),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique (user_id, entry_date)
);

-- -----------------------------------------------------------------------------
-- 8. food_images – metadata for files in private Storage buckets
--    object_path must start with the owner's user id folder.
-- -----------------------------------------------------------------------------
create table if not exists public.food_images (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid()
                 references auth.users (id) on delete cascade,
  bucket_id    text not null check (bucket_id in ('label-scans','food-photos')),
  object_path  text not null,
  purpose      text not null check (purpose in ('label_scan','product_photo')),
  food_id      uuid references public.foods (id) on delete set null,
  mime_type    text not null check (mime_type in ('image/jpeg','image/png','image/webp')),
  size_bytes   integer check (size_bytes > 0 and size_bytes <= 10485760),
  width_px     integer check (width_px > 0),
  height_px    integer check (height_px > 0),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique (bucket_id, object_path),
  constraint food_images_path_in_own_folder
    check (split_part(object_path, '/', 1) = user_id::text)
);

-- -----------------------------------------------------------------------------
-- 9. ai_interactions – audit log of every Claude call (no images stored here)
-- -----------------------------------------------------------------------------
create table if not exists public.ai_interactions (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null default auth.uid()
                       references auth.users (id) on delete cascade,
  kind               text not null check (kind in ('label_scan','assistant','meal_suggestions')),
  conversation_id    uuid,
  user_message       text check (char_length(user_message) <= 8000),
  assistant_message  text check (char_length(assistant_message) <= 60000),
  model              text,
  input_tokens       integer check (input_tokens >= 0),
  output_tokens      integer check (output_tokens >= 0),
  status             text not null default 'ok' check (status in ('ok','error','rejected')),
  error_code         text,
  metadata           jsonb not null default '{}'::jsonb,
  food_image_id      uuid references public.food_images (id) on delete set null,
  created_at         timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- 10. ai_drafts – anything Claude proposes waits here for explicit approval
-- -----------------------------------------------------------------------------
create table if not exists public.ai_drafts (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null default auth.uid()
                    references auth.users (id) on delete cascade,
  interaction_id  uuid references public.ai_interactions (id) on delete set null,
  draft_type      text not null check (draft_type in ('diary_entry','food','recipe','meal_plan')),
  payload         jsonb not null check (jsonb_typeof(payload) = 'object'),
  status          text not null default 'pending'
                    check (status in ('pending','approved','rejected','expired')),
  decided_at      timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint ai_drafts_decision_time check ((status = 'pending') = (decided_at is null))
);
comment on table public.ai_drafts is 'Claude suggestions. Nothing reaches the diary/library until the user approves in the app.';

-- =============================================================================
-- Indexes
-- =============================================================================
create index if not exists profiles_user_idx              on public.profiles (user_id);
create index if not exists nutrition_targets_lookup_idx   on public.nutrition_targets (user_id, effective_from desc);

create index if not exists foods_user_idx                 on public.foods (user_id) where archived_at is null;
create index if not exists foods_user_favourite_idx       on public.foods (user_id, is_favourite) where archived_at is null;
create index if not exists foods_user_category_idx        on public.foods (user_id, category) where archived_at is null;
create index if not exists foods_search_trgm_idx          on public.foods using gin (search_text extensions.gin_trgm_ops);
-- No duplicate barcodes per user among live products
create unique index if not exists foods_user_barcode_uniq on public.foods (user_id, barcode)
  where barcode is not null and archived_at is null;

create index if not exists recipes_user_idx               on public.recipes (user_id) where archived_at is null;
create index if not exists recipe_ingredients_recipe_idx  on public.recipe_ingredients (recipe_id, position);
create index if not exists recipe_ingredients_food_idx    on public.recipe_ingredients (food_id);
create index if not exists recipe_ingredients_user_idx    on public.recipe_ingredients (user_id);

create index if not exists food_diary_user_date_idx       on public.food_diary (user_id, entry_date, meal, position);
create index if not exists food_diary_food_idx            on public.food_diary (food_id) where food_id is not null;
create index if not exists food_diary_recipe_idx          on public.food_diary (recipe_id) where recipe_id is not null;

create index if not exists weight_entries_user_date_idx   on public.weight_entries (user_id, entry_date desc);

create index if not exists food_images_user_idx           on public.food_images (user_id, created_at desc);
create index if not exists food_images_food_idx           on public.food_images (food_id) where food_id is not null;

create index if not exists ai_interactions_user_time_idx  on public.ai_interactions (user_id, created_at desc);
create index if not exists ai_interactions_conversation_idx on public.ai_interactions (user_id, conversation_id, created_at)
  where conversation_id is not null;
create index if not exists ai_interactions_image_idx      on public.ai_interactions (food_image_id) where food_image_id is not null;

create index if not exists ai_drafts_user_status_idx      on public.ai_drafts (user_id, status, created_at desc);
create index if not exists ai_drafts_interaction_idx      on public.ai_drafts (interaction_id) where interaction_id is not null;
