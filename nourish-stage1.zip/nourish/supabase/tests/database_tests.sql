-- =============================================================================
-- Nourish database tests – LOCAL ONLY (run via scripts/test-database.sh).
-- Uses two throwaway users, A and B, and fixed ids. Every check raises an
-- exception on failure, so the run stops at the first problem.
-- =============================================================================
\set ON_ERROR_STOP on
\set QUIET on
set client_min_messages = notice;

reset role;
create schema if not exists test;
create or replace function test.eq(actual numeric, expected numeric, label text) returns void
language plpgsql as $$
begin
  if actual is distinct from expected then
    raise exception 'FAIL: % (expected %, got %)', label, expected, actual;
  end if;
  raise notice 'PASS: %', label;
end $$;
create or replace function test.ok(condition boolean, label text) returns void
language plpgsql as $$
begin
  if condition is not true then raise exception 'FAIL: %', label; end if;
  raise notice 'PASS: %', label;
end $$;
grant usage on schema test to anon, authenticated;
grant execute on all functions in schema test to anon, authenticated;

-- Test users
insert into auth.users (id, email) values
  ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', 'a@example.test'),
  ('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb', 'b@example.test');

\echo '--- Sign-up defaults'
select test.eq((select count(*) from public.profiles), 2, 'profile created for each new user');
select test.eq((select energy_kcal from public.nutrition_targets where user_id = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'), 1800, 'default calorie target 1800 kcal');
select test.ok((select protein_g = 160 and carbs_g = 150 and fat_g = 60 and fibre_g = 30 and salt_g = 6
                from public.nutrition_targets where user_id = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'),
               'default macro targets 160/150/60/30/6');

-- ---------------------------------------------------------------------------
\echo '--- User A: foods and diary calculations'
set role authenticated;
set request.jwt.claims = '{"sub":"aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa","role":"authenticated"}';

insert into public.foods (id, name, brand, barcode, category, energy_kcal_100, protein_g_100, carbs_g_100,
                          sugars_g_100, fat_g_100, sat_fat_g_100, fibre_g_100, salt_g_100)
values ('11111111-1111-4111-8111-111111111111', '  Porridge Oats ', 'Test Mill', '5000 1234 5678 9', 'Cereals',
        120, 10, 60, 1, 8, 1.5, 9, 0.02);

select test.ok((select name = 'Porridge Oats' and barcode = '5000123456789'
                from public.foods where id = '11111111-1111-4111-8111-111111111111'),
               'name trimmed and barcode spaces removed');

insert into public.food_diary (id, entry_date, meal, food_id, quantity, quantity_unit)
values ('d1111111-1111-4111-8111-111111111111', current_date, 'breakfast',
        '11111111-1111-4111-8111-111111111111', 150, 'g');

select test.eq((select energy_kcal from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'), 180, '150 g of a 120 kcal/100 g food = 180 kcal');
select test.eq((select protein_g   from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'), 15,   'protein 10 g/100 g × 150 g = 15 g');
select test.eq((select carbs_g     from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'), 90,   'carbs 60 g/100 g × 150 g = 90 g');
select test.eq((select fat_g       from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'), 12,   'fat 8 g/100 g × 150 g = 12 g');
select test.eq((select fibre_g     from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'), 13.5, 'fibre 9 g/100 g × 150 g = 13.5 g');
select test.eq((select salt_g      from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'), 0.03, 'salt 0.02 g/100 g × 150 g = 0.03 g');
select test.ok((select item_name = 'Porridge Oats' and item_brand = 'Test Mill'
                from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'),
               'diary snapshot copied name and brand from library');

\echo '--- Historical accuracy: editing a food does not change past diary entries'
update public.foods set energy_kcal_100 = 200 where id = '11111111-1111-4111-8111-111111111111';
select test.eq((select energy_kcal from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'), 180, 'diary still 180 kcal after food changed to 200 kcal/100 g');

update public.food_diary set quantity = 200 where id = 'd1111111-1111-4111-8111-111111111111';
select test.eq((select energy_kcal from public.food_diary where id = 'd1111111-1111-4111-8111-111111111111'), 240, 'editing quantity to 200 g recalculates from snapshot (240 kcal)');

do $$ begin
  begin
    update public.food_diary set quantity_unit = 'ml' where id = 'd1111111-1111-4111-8111-111111111111';
    raise exception 'FAIL: unit change on a linked entry was allowed';
  exception when invalid_parameter_value then raise notice 'PASS: unit of a logged food cannot be changed';
  end;
end $$;

\echo '--- Manual quick-add in portions'
insert into public.food_diary (id, entry_date, meal, quantity, quantity_unit, item_name, snap_energy_kcal, snap_protein_g)
values ('d2222222-2222-4222-8222-222222222222', current_date, 'dinner', 0.5, 'portion', 'Takeaway curry', 650, 40);
select test.eq((select energy_kcal from public.food_diary where id = 'd2222222-2222-4222-8222-222222222222'), 325, 'half a 650 kcal portion = 325 kcal');
select test.ok((select fat_g is null from public.food_diary where id = 'd2222222-2222-4222-8222-222222222222'), 'unknown nutrients stay NULL, not zero');

select test.eq((select energy_kcal from public.daily_nutrition_totals where entry_date = current_date), 565, 'daily total 240 + 325 = 565 kcal');
select test.eq((select entries_missing_nutrients from public.daily_nutrition_totals where entry_date = current_date), 1, 'daily total flags 1 entry with missing nutrients');

\echo '--- Duplicate protection and AI approval rule'
do $$ begin
  begin
    insert into public.foods (name, barcode) values ('Same oats again', '5000123456789');
    raise exception 'FAIL: duplicate barcode accepted';
  exception when unique_violation then raise notice 'PASS: duplicate barcode rejected for the same user';
  end;
end $$;

do $$ begin
  begin
    insert into public.foods (name, source, energy_kcal_100) values ('Unapproved scan', 'ai_scan', 250);
    raise exception 'FAIL: unverified AI scan saved';
  exception when check_violation then raise notice 'PASS: AI-scanned food cannot be saved without user approval';
  end;
end $$;
insert into public.foods (name, source, verified_at, energy_kcal_100) values ('Approved scan', 'ai_scan', now(), 250);
select test.ok(true, 'AI-scanned food saves once verified_at is set');

select test.ok((select count(*) = 1 from public.search_foods('oat', 10)), 'search_foods finds "oat"');
select test.ok((select count(*) = 1 from public.find_similar_foods('porridge oats', 'test mill', null)), 'find_similar_foods matches by name');
select test.ok((select match_reason = 'barcode' from public.find_similar_foods('x', null, '5000123456789')), 'find_similar_foods matches by barcode');

\echo '--- Recipes'
insert into public.foods (id, name, base_unit, energy_kcal_100, protein_g_100, carbs_g_100, sugars_g_100,
                          fat_g_100, sat_fat_g_100, fibre_g_100, salt_g_100)
values ('22222222-2222-4222-8222-222222222222', 'Semi-skimmed milk', 'ml', 50, 3.6, 4.8, 4.8, 1.8, 1.1, 0, 0.1);

insert into public.recipes (id, name, portions) values ('44444444-4444-4444-8444-444444444444', 'Overnight oats', 2);
insert into public.recipe_ingredients (recipe_id, food_id, quantity, unit) values
  ('44444444-4444-4444-8444-444444444444', '11111111-1111-4111-8111-111111111111', 100, 'g'),
  ('44444444-4444-4444-8444-444444444444', '22222222-2222-4222-8222-222222222222', 200, 'ml');

select test.eq((select total_energy_kcal from public.recipe_nutrition where recipe_id = '44444444-4444-4444-8444-444444444444'), 300, 'recipe total 100 g oats (200) + 200 ml milk (100) = 300 kcal');
select test.eq((select portion_energy_kcal from public.recipe_nutrition where recipe_id = '44444444-4444-4444-8444-444444444444'), 150, 'per portion (2 portions) = 150 kcal');
select test.eq((select portion_protein_g from public.recipe_nutrition where recipe_id = '44444444-4444-4444-8444-444444444444'), 8.6, 'per portion protein (10 + 7.2) ÷ 2 = 8.6 g');

do $$ begin
  begin
    insert into public.recipe_ingredients (recipe_id, food_id, quantity, unit)
    values ('44444444-4444-4444-8444-444444444444', '22222222-2222-4222-8222-222222222222', 50, 'g');
    raise exception 'FAIL: wrong unit accepted';
  exception when invalid_parameter_value then raise notice 'PASS: ingredient unit must match the food (ml for milk)';
  end;
end $$;

insert into public.food_diary (id, entry_date, meal, recipe_id, quantity, quantity_unit)
values ('d3333333-3333-4333-8333-333333333333', current_date, 'lunch', '44444444-4444-4444-8444-444444444444', 1, 'portion');
select test.eq((select energy_kcal from public.food_diary where id = 'd3333333-3333-4333-8333-333333333333'), 150, 'one recipe portion logged = 150 kcal');

update public.recipe_ingredients set quantity = 300 where food_id = '22222222-2222-4222-8222-222222222222';
select test.eq((select energy_kcal from public.food_diary where id = 'd3333333-3333-4333-8333-333333333333'), 150, 'changing the recipe later does not alter the logged portion');

\echo '--- Deletion rules'
do $$ begin
  begin
    delete from public.foods where id = '22222222-2222-4222-8222-222222222222';
    raise exception 'FAIL: deleted a food used by a recipe';
  exception when foreign_key_violation then raise notice 'PASS: a food used in a recipe cannot be deleted (archive instead)';
  end;
end $$;

insert into public.foods (id, name, energy_kcal_100, protein_g_100) values ('33333333-3333-4333-8333-333333333333', 'Banana', 89, 1.1);
insert into public.food_diary (id, entry_date, meal, food_id, quantity) values
  ('d4444444-4444-4444-8444-444444444444', current_date - 1, 'snacks', '33333333-3333-4333-8333-333333333333', 120);
delete from public.foods where id = '33333333-3333-4333-8333-333333333333';
select test.ok((select food_id is null and item_name = 'Banana' and energy_kcal = 106.8
                from public.food_diary where id = 'd4444444-4444-4444-8444-444444444444'),
               'deleting a food keeps past diary entries and their 106.8 kcal');

\echo '--- Explicit snapshot refresh and copying meals'
select test.eq((select energy_kcal from public.refresh_diary_entry_snapshot('d1111111-1111-4111-8111-111111111111')), 400, 'refresh on request uses current 200 kcal/100 g × 200 g = 400 kcal');
select test.eq((select public.copy_meal(current_date, 'breakfast', current_date + 1, 'lunch')), 1, 'copy_meal copied 1 item');
select test.eq((select energy_kcal from public.food_diary where entry_date = current_date + 1 and meal = 'lunch'), 400, 'copied item keeps quantity and current values');

\echo '--- Targets by date'
insert into public.nutrition_targets (effective_from, energy_kcal) values (current_date + 7, 1700);
select test.eq((select energy_kcal from public.get_nutrition_targets(current_date)), 1800, 'targets for today = 1800');
select test.eq((select energy_kcal from public.get_nutrition_targets(current_date + 10)), 1700, 'targets after change = 1700');
select test.eq((select energy_kcal from public.get_nutrition_targets(current_date - 30)), 1800, 'targets before first row fall back to earliest');

\echo '--- Weight tracking'
insert into public.weight_entries (entry_date, weight_kg) values (current_date - 20, 90.0), (current_date - 5, 88.5);
select test.ok((select current_weight_kg = 88.5 and start_weight_kg = 90.0 from public.profiles), 'profile current = latest (88.5), start = first (90.0)');
insert into public.weight_entries (entry_date, weight_kg) values (current_date - 40, 91.2);
select test.eq((select current_weight_kg from public.profiles), 88.5, 'adding an older entry does not change current weight');
delete from public.weight_entries where entry_date = current_date - 5;
select test.eq((select current_weight_kg from public.profiles), 90.0, 'deleting latest entry falls back to previous (90.0)');
select test.eq((select count(*) from public.weight_entries), 2, 'other weight entries untouched');

\echo '--- AI drafts and audit log'
insert into public.ai_interactions (id, kind, user_message, assistant_message, model)
values ('55555555-5555-4555-8555-555555555555', 'assistant', 'What can I eat?', 'Try…', 'test-model');
insert into public.ai_drafts (id, interaction_id, draft_type, payload)
values ('66666666-6666-4666-8666-666666666666', '55555555-5555-4555-8555-555555555555', 'diary_entry', '{"item_name":"Omelette"}');
select test.ok((select decided_at is null from public.ai_drafts), 'new draft is pending with no decision time');
update public.ai_drafts set status = 'approved' where id = '66666666-6666-4666-8666-666666666666';
select test.ok((select decided_at is not null from public.ai_drafts), 'approving a draft stamps decided_at');
do $$ begin
  begin
    update public.ai_interactions set assistant_message = 'rewritten';
    raise exception 'FAIL: audit log was editable';
  exception when insufficient_privilege then raise notice 'PASS: AI audit log cannot be edited';
  end;
end $$;

\echo '--- Storage: own folder only'
insert into storage.objects (bucket_id, name) values ('label-scans', 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa/scan-1.jpg');
select test.ok(true, 'A can upload into their own folder');
do $$ begin
  begin
    insert into storage.objects (bucket_id, name) values ('label-scans', 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/sneaky.jpg');
    raise exception 'FAIL: uploaded into another user''s folder';
  exception when insufficient_privilege then raise notice 'PASS: A cannot upload into B''s folder';
  end;
end $$;
do $$ begin
  begin
    insert into public.food_images (bucket_id, object_path, purpose, mime_type)
    values ('label-scans', 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb/x.jpg', 'label_scan', 'image/jpeg');
    raise exception 'FAIL: image record outside own folder accepted';
  exception when check_violation then raise notice 'PASS: image records must point inside the owner''s folder';
  end;
end $$;

-- ---------------------------------------------------------------------------
\echo '--- User B: isolation from user A'
set request.jwt.claims = '{"sub":"bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb","role":"authenticated"}';

select test.eq((select count(*) from public.foods), 0,              'B sees none of A''s foods');
select test.eq((select count(*) from public.food_diary), 0,         'B sees none of A''s diary');
select test.eq((select count(*) from public.profiles), 1,           'B sees only their own profile');
select test.eq((select count(*) from public.weight_entries), 0,     'B sees none of A''s weights');
select test.eq((select count(*) from public.recipes), 0,            'B sees none of A''s recipes');
select test.eq((select count(*) from public.ai_interactions), 0,    'B sees none of A''s AI history');
select test.eq((select count(*) from public.daily_nutrition_totals), 0, 'B''s totals view is empty');
select test.eq((select count(*) from public.recipe_nutrition), 0,   'B''s recipe view is empty');
select test.eq((select count(*) from storage.objects), 0,           'B cannot list A''s images');
select test.eq((select count(*) from public.search_foods('oat', 10)), 0, 'B''s search cannot find A''s foods');

with u as (update public.food_diary set quantity = 1 returning 1) select test.eq((select count(*) from u), 0, 'B cannot update A''s diary');
with d as (delete from public.foods returning 1)                  select test.eq((select count(*) from d), 0, 'B cannot delete A''s foods');

do $$ begin
  begin
    insert into public.food_diary (entry_date, meal, food_id, quantity)
    values (current_date, 'lunch', '11111111-1111-4111-8111-111111111111', 100);
    raise exception 'FAIL: B logged A''s food';
  exception when foreign_key_violation then raise notice 'PASS: B cannot log a food from A''s library';
  end;
end $$;

do $$ begin
  begin
    insert into public.foods (user_id, name) values ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', 'Planted food');
    raise exception 'FAIL: B wrote into A''s library';
  exception when insufficient_privilege then raise notice 'PASS: B cannot create records owned by A';
  end;
end $$;

insert into public.foods (name, barcode) values ('B''s oats', '5000123456789');
select test.ok(true, 'B can save the same barcode in their own library');

-- ---------------------------------------------------------------------------
\echo '--- Signed-out (anon) access'
reset request.jwt.claims;
set role anon;
do $$ begin
  begin
    perform 1 from public.foods limit 1;
    raise exception 'FAIL: anon could read foods';
  exception when insufficient_privilege then raise notice 'PASS: signed-out visitors cannot read any table';
  end;
end $$;
do $$ begin
  begin
    perform public.search_foods('oat', 5);
    raise exception 'FAIL: anon could call search_foods';
  exception when insufficient_privilege then raise notice 'PASS: signed-out visitors cannot call data functions';
  end;
end $$;
select test.ok((select bool_and((v ->> 'exists')::boolean and (v ->> 'rls')::boolean)
                from jsonb_each(public.nourish_health_check() -> 'tables') as t(k, v)),
               'health check: all 10 tables exist with RLS enabled');
select test.ok((select jsonb_array_length(public.nourish_health_check() -> 'buckets') = 2
                   and not bool_or((b ->> 'public')::boolean)
                from jsonb_array_elements(public.nourish_health_check() -> 'buckets') b),
               'health check: both storage buckets exist and are private');

reset role;
\echo '=== ALL DATABASE TESTS PASSED ==='
